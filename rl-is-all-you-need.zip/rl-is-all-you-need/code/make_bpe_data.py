"""Full-mathlib corpus -> byte-level BPE (8k) -> uint16 token arrays.

Usage: python make_bpe_data.py [--mathlib DIR] [--vocab 8192]
Writes data_bpe/{tokenizer.json, train.bin, val.bin}. Files are split by path
(every 50th file goes to validation), so validation text is unseen.
"""
import argparse
import os
import re

import numpy as np
from tokenizers import Tokenizer, decoders, models, pre_tokenizers, trainers

ap = argparse.ArgumentParser()
ap.add_argument("--mathlib", default=os.environ.get("MATHLIB_SRC", "../lean/.lake/packages/mathlib/Mathlib"))
ap.add_argument("--vocab", type=int, default=8192)
ap.add_argument("--out", default="data_bpe")
a = ap.parse_args()
os.makedirs(a.out, exist_ok=True)

HEADER = re.compile(r"^/-\s*\nCopyright.*?-/\s*\n", re.S)
DROP = re.compile(r"^(public )?(import .*|module)\s*$", re.M)
files = sorted(os.path.join(r, f) for r, _, fs in os.walk(a.mathlib) for f in fs if f.endswith(".lean"))
train, val = [], []
for i, f in enumerate(files):
    s = DROP.sub("", HEADER.sub("", open(f, encoding="utf-8").read())).strip() + "\n\n"
    (val if i % 50 == 0 else train).append(s)
print(f"{len(files)} files, train {sum(map(len, train)) / 1e6:.1f}M chars, val {sum(map(len, val)) / 1e6:.1f}M chars")

tok = Tokenizer(models.BPE())
tok.pre_tokenizer = pre_tokenizers.ByteLevel(add_prefix_space=False)
tok.decoder = decoders.ByteLevel()
tok.train_from_iterator(train, trainers.BpeTrainer(
    vocab_size=a.vocab, initial_alphabet=pre_tokenizers.ByteLevel.alphabet(), show_progress=False))
tok.save(os.path.join(a.out, "tokenizer.json"))

for name, docs in (("train", train), ("val", val)):
    ids = np.concatenate([np.array(e.ids, dtype=np.uint16) for e in tok.encode_batch(docs)])
    ids.tofile(os.path.join(a.out, f"{name}.bin"))
    print(f"{name}: {len(ids) / 1e6:.1f}M tokens")
ex = "theorem add_comm (a b : ℕ) : a + b = b + a := by omega"
print(tok.encode(ex).tokens)
