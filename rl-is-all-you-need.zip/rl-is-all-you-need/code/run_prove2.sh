#!/bin/bash
# Stage 2 on miniF2F: wait for the stage-1 checkpoint, then RL from the Mathlib verifier.
# Usage: bash run_prove2.sh <reward: log|brier> <anchor λ> [steps]
cd "$(dirname "$0")"
PY=${PY:-python3}
R=${1:-log}; A=${2:-0.5}; S=${3:-100}
while [ ! -f results/bpe_$R.json ]; do sleep 30; done      # written when pretraining ends
$PY rl_prove2.py --ckpt ckpt/bpe_$R.pt --anchor $A --anchor_reward $R --steps $S \
  --eval_K 8 --out results/prove2_${R}_a$A.json 2>&1 | grep -v -i warn > results/prove2_${R}_a$A.log
grep '"step"' results/prove2_${R}_a$A.log
