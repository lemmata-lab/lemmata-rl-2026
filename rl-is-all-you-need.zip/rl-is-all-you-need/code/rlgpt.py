"""RL-GPT: a tiny GPT trained by reinforcement learning only (prototype).

The model is an ordinary decoder-only Transformer. What changes is the training
signal. In every RL mode the next token x is hidden inside the environment and
used ONLY to compute a scalar reward; no gradient ever flows from x.

  ntp      cross-entropy baseline (ordinary GPT pre-training)
  brier    action = whole next-token distribution q, reward = Brier score
           S(q,x) = 1 - 1/2 ||q - e_x||^2 (strictly proper; paper Sec. 3).
           The reward is differentiable in the action, so this is a
           deterministic policy gradient.
  pg       action = K sampled tokens A_1..A_K ~ q, fair group Brier reward
           (U-statistic; K=2 is the fair Brier score of Prop. 2). REINFORCE.
  pgv      same with the biased V-statistic reward (Prop. 5): sharpens q.
  pg1      action = one sampled token, reward 1{A=x} (+ optional entropy bonus).
           Linear in q, so the optimum is the mode (Prop. 1).

Usage: python rlgpt.py --data synth|text --method ntp|brier|pg|pgv|pg1 [--K 8]
"""
import argparse
import json
import math
import os
import time

import torch
import torch.nn as nn
import torch.nn.functional as F


# ----------------------------------------------------------------- model
class Block(nn.Module):
    def __init__(self, d, h, T, p):
        super().__init__()
        self.ln1, self.ln2 = nn.LayerNorm(d), nn.LayerNorm(d)
        self.attn = nn.MultiheadAttention(d, h, dropout=p, batch_first=True)
        self.mlp = nn.Sequential(nn.Linear(d, 4 * d), nn.GELU(), nn.Linear(4 * d, d), nn.Dropout(p))
        self.register_buffer("mask", torch.triu(torch.ones(T, T, dtype=torch.bool), 1))

    def forward(self, x):
        T = x.size(1)
        y = self.ln1(x)
        x = x + self.attn(y, y, y, attn_mask=self.mask[:T, :T], need_weights=False)[0]
        return x + self.mlp(self.ln2(x))


class GPT(nn.Module):
    def __init__(self, V, T, d, L, h, p=0.0):
        super().__init__()
        self.T = T
        self.tok, self.pos = nn.Embedding(V, d), nn.Embedding(T, d)
        self.blocks = nn.Sequential(*[Block(d, h, T, p) for _ in range(L)])
        self.ln, self.head = nn.LayerNorm(d), nn.Linear(d, V, bias=False)

    def forward(self, idx):
        pos = torch.arange(idx.size(1), device=idx.device)
        return self.head(self.ln(self.blocks(self.tok(idx) + self.pos(pos))))

    @torch.no_grad()
    def generate(self, idx, n, temp=1.0):
        for _ in range(n):
            logits = self(idx[:, -self.T:])[:, -1] / temp
            idx = torch.cat([idx, torch.multinomial(F.softmax(logits, -1), 1)], 1)
        return idx


# ------------------------------------------------------------ objectives
def objective(method, logits, x, K=8, beta=0.0):
    """Loss to minimise. `x` (true next tokens) is used only by the environment."""
    V = logits.size(-1)
    logp = F.log_softmax(logits.float(), -1)
    if method == "ntp":
        return F.nll_loss(logp, x)
    q = logp.exp()
    if method == "brier":
        # Action = q itself; the environment returns S(q, x). Gradient flows through q.
        r = 1 - 0.5 * ((q - F.one_hot(x, V)) ** 2).sum(-1)
        return -r.mean()
    # Token-sampling policies: the agent only sees a scalar reward per sample.
    with torch.no_grad():
        A = torch.multinomial(q, K, replacement=True)            # [N, K]
        hit = (A == x[:, None]).float()
        if method == "pg1":
            r = hit
        else:
            coll = (A[:, :, None] == A[:, None, :]).float().sum(-1) - 1  # matches among the others
            # Per-sample credit: E[sum_k r_k grad log q(A_k)] = K * grad(2<q,p> - c||q||^2),
            # c = 1 for the fair (U) reward, c = (K-1)/K for the biased (V) reward.
            w = 2 / (K - 1) if method == "pg" else 2 / K
            r = 2 * hit - w * coll
        adv = r - r.mean()                                        # batch baseline
    loss = -(adv * logp.gather(1, A)).sum(-1).mean() / K
    if beta:
        loss = loss - beta * (-(q * logp).sum(-1)).mean()
    return loss


# ------------------------------------------------------------------ data
class Synth:
    """Order-2 Markov source with Dirichlet rows: the true next-token law mu is known."""

    def __init__(self, V=16, alpha=0.5, chains=2048, length=2048, seed=0, dev="cuda"):
        g = torch.Generator().manual_seed(seed)
        P = torch.distributions.Dirichlet(torch.full((V,), alpha)).sample((V * V,))
        self.P = P.to(dev)                                        # row index = 16*a + b
        x = torch.randint(V, (chains, length), generator=g).to(dev)
        u = torch.rand(chains, length, generator=g).to(dev)
        cdf = self.P.cumsum(-1)
        for t in range(2, length):
            row = cdf[x[:, t - 2] * V + x[:, t - 1]]
            x[:, t] = torch.searchsorted(row, u[:, t, None].contiguous()).squeeze(1).clamp_max(V - 1)
        self.V, self.x, self.dev = V, x, dev
        self.ntrain = int(chains * 0.9)

    def batch(self, B, T, split="train"):
        lo, hi = (0, self.ntrain) if split == "train" else (self.ntrain, self.x.size(0))
        c = torch.randint(lo, hi, (B,), device=self.dev)
        o = torch.randint(0, self.x.size(1) - T - 1, (B,), device=self.dev)
        idx = o[:, None] + torch.arange(T + 1, device=self.dev)
        w = self.x[c[:, None], idx]
        return w[:, :-1], w[:, 1:]

    def true_next(self, inp):
        """mu(. | last two tokens) for positions 1..T-1 of the input window."""
        return self.P[inp[:, :-1] * self.V + inp[:, 1:]]


class Text:
    def __init__(self, path, dev="cuda"):
        s = open(path, encoding="utf-8", errors="ignore").read()
        self.chars = sorted(set(s))
        self.stoi = {c: i for i, c in enumerate(self.chars)}
        d = torch.tensor([self.stoi[c] for c in s], device=dev)
        n = int(len(d) * 0.9)
        self.tr, self.va, self.V, self.dev = d[:n], d[n:], len(self.chars), dev

    def batch(self, B, T, split="train"):
        d = self.tr if split == "train" else self.va
        o = torch.randint(0, len(d) - T - 1, (B,), device=self.dev)
        idx = o[:, None] + torch.arange(T + 1, device=self.dev)
        w = d[idx]
        return w[:, :-1], w[:, 1:]

    def decode(self, ids):
        return "".join(self.chars[i] for i in ids)


# ------------------------------------------------------------ evaluation
@torch.no_grad()
def evaluate(model, data, T, n=16, B=256):
    model.eval()
    ce = sq = kl = acc = 0.0
    for _ in range(n):
        inp, tgt = data.batch(B, T, "val")
        logp = F.log_softmax(model(inp).float(), -1)
        ce += F.nll_loss(logp.reshape(-1, data.V), tgt.reshape(-1)).item()
        if isinstance(data, Synth):
            mu, lq = data.true_next(inp), logp[:, 1:]
            sq += ((lq.exp() - mu) ** 2).sum(-1).mean().item()
            kl += (mu * (mu.clamp_min(1e-12).log() - lq)).sum(-1).mean().item()
            acc += (lq.argmax(-1) == mu.argmax(-1)).float().mean().item()
    model.train()
    out = {"val_bits": ce / n / math.log(2)}
    if isinstance(data, Synth):
        out |= {"sq_err": sq / n, "kl": kl / n, "mode_acc": acc / n}
    return out


# ------------------------------------------------------------------ main
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default="synth")
    ap.add_argument("--text", default="corpus.txt")
    ap.add_argument("--method", default="pg")
    ap.add_argument("--K", type=int, default=8)
    ap.add_argument("--beta", type=float, default=0.0)
    ap.add_argument("--steps", type=int, default=3000)
    ap.add_argument("--lr", type=float, default=1e-3)
    ap.add_argument("--B", type=int, default=64)
    ap.add_argument("--T", type=int, default=64)
    ap.add_argument("--d", type=int, default=128)
    ap.add_argument("--L", type=int, default=4)
    ap.add_argument("--heads", type=int, default=4)
    ap.add_argument("--drop", type=float, default=0.0)
    ap.add_argument("--prompt", default="The ")
    ap.add_argument("--tag", default="", help="prefix for the result name")
    ap.add_argument("--save", default="", help="checkpoint path")
    ap.add_argument("--seed", type=int, default=1)
    ap.add_argument("--eval_every", type=int, default=250)
    ap.add_argument("--out", default="results")
    a = ap.parse_args()

    dev = "cuda" if torch.cuda.is_available() else "cpu"
    torch.manual_seed(a.seed)
    data = Synth(dev=dev) if a.data == "synth" else Text(a.text, dev)
    model = GPT(data.V, a.T, a.d, a.L, a.heads, a.drop).to(dev)
    opt = torch.optim.AdamW(model.parameters(), lr=a.lr, weight_decay=0.01)
    sched = torch.optim.lr_scheduler.LambdaLR(
        opt, lambda s: min(1, (s + 1) / 100) * 0.5 * (1 + math.cos(math.pi * s / a.steps)))

    name = f"{a.tag or a.data}_{a.method}" + (f"_K{a.K}" if a.method in ("pg", "pgv") else "") \
        + (f"_b{a.beta}" if a.beta else "")
    log, t0 = [], time.time()
    for step in range(a.steps + 1):
        if step % a.eval_every == 0:
            m = evaluate(model, data, a.T) | {"step": step, "sec": round(time.time() - t0, 1)}
            log.append(m)
            print(name, json.dumps(m), flush=True)
        if step == a.steps:
            break
        inp, tgt = data.batch(a.B, a.T)
        logits = model(inp)
        loss = objective(a.method, logits.reshape(-1, data.V), tgt.reshape(-1), a.K, a.beta)
        opt.zero_grad(set_to_none=True)
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        opt.step()
        sched.step()

    res = {"name": name, "args": vars(a), "log": log}
    if isinstance(data, Text):
        prompt = torch.tensor([[data.stoi[c] for c in a.prompt]], device=dev)
        res["sample"] = data.decode(model.generate(prompt, 400)[0].tolist())
        print(res["sample"])
    os.makedirs(a.out, exist_ok=True)
    json.dump(res, open(os.path.join(a.out, name + ".json"), "w"), indent=1)
    if a.save:
        cfg = {"V": data.V, "T": a.T, "d": a.d, "L": a.L, "h": a.heads}
        chars = getattr(data, "chars", None)
        torch.save({"cfg": cfg, "chars": chars, "state": model.state_dict()}, a.save)


if __name__ == "__main__":
    main()
