#!/bin/bash
# Synthetic order-2 Markov source (V=16) with known truth. Usage: bash run_synth.sh [steps] [outdir]
cd "$(dirname "$0")"
PY=${PY:-python3}
S=${1:-3000}
O=${2:-results}
E=$(( S / 12 > 0 ? S / 12 : 1 ))
for args in "--method ntp" "--method brier" "--method pg --K 2" "--method pg --K 8" \
            "--method pgv --K 2" "--method pg1" "--method pg1 --beta 0.05"; do
  $PY rlgpt.py --data synth $args --steps $S --eval_every $E --out $O | tail -1
done
