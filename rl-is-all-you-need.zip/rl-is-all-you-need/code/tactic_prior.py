"""How often does the stage-1 policy propose each tactic? (exploration diagnosis)

Samples K one-line proofs per miniF2F valid problem from a checkpoint and reports
the frequency of the leading tactic word, and the probability of `grind`.
Usage: python tactic_prior.py [ckpt] [K] [temp]
"""
import json
import sys
from collections import Counter

import torch
from tokenizers import Tokenizer

from gpt import GPT
from rl_prove2 import Policy

ck = sys.argv[1] if len(sys.argv) > 1 else "ckpt/bpe_log.pt"
K = int(sys.argv[2]) if len(sys.argv) > 2 else 32
temp = float(sys.argv[3]) if len(sys.argv) > 3 else 1.0
torch.manual_seed(0)
pol = Policy(GPT.load(ck), Tokenizer.from_file("data_bpe/tokenizer.json"))
pol.m.eval()
probs = [p for p in json.load(open("data_minif2f/minif2f_checked.json")) if p["ok"] and p["split"] == "valid"]
heads = Counter()
n = 0
for p in probs:
    _, _, texts = pol.sample(pol.prompt_ids(p["formal_statement"]), K, temp=temp)
    for t in texts:
        heads[(t.split() or [""])[0]] += 1
        n += 1
print(f"{n} samples, temp {temp}")
for h, c in heads.most_common(25):
    print(f"{c / n:7.4f}  {h}")
print("grind:", heads["grind"] / n, " expected grind samples per RL step (8x16):", 128 * heads["grind"] / n)
