"""Stage 2 at BPE scale: RL from the Mathlib verifier on miniF2F.

The policy (a stage-1 checkpoint from pretrain_bpe.py) reads a formal statement
ending in `:= by` and samples K one-line tactic scripts; Mathlib checks them;
reward 1 if accepted. Group-normalised advantages (GRPO style). The stage-1
proper-score reward on corpus text can be kept as an anchor (--anchor λ).

RL is done on the miniF2F `valid` split; `test` is held out for evaluation.

Usage: python rl_prove2.py --ckpt ckpt/bpe_log.pt --anchor 0.5
"""
import argparse
import json
import os
import random
import re
import time
from collections import Counter

import numpy as np
import torch
import torch.nn.functional as F
from tokenizers import Tokenizer

from gpt import GPT
from mathlib_verify import check_many
from pretrain_bpe import score


class Policy:
    def __init__(self, model, tok, max_new=40):
        self.m, self.tok, self.max_new = model, tok, max_new

    def prompt_ids(self, stmt):
        # End at `by`: BPE merges the following newline with the indentation, so a
        # prompt ending in a bare newline token is out of distribution.
        ids = self.tok.encode(stmt.rstrip()).ids
        return torch.tensor(ids[-(self.m.T - self.max_new):], device="cuda")

    @torch.no_grad()
    def sample(self, pid, K, temp=1.0):
        """K completions; each is cut after the first non-empty line."""
        idx = pid[None].repeat(K, 1)
        P = idx.size(1)
        done = [False] * K
        n_used = [self.max_new] * K
        for t in range(self.max_new):
            with torch.autocast("cuda", torch.bfloat16):
                logits = self.m(idx[:, -self.m.T:])[:, -1].float() / temp
            idx = torch.cat([idx, torch.multinomial(F.softmax(logits, -1), 1)], 1)
            for k in range(K):
                if not done[k]:
                    s = self.tok.decode(idx[k, P:].tolist()).lstrip("\n ")
                    if "\n" in s:
                        done[k], n_used[k] = True, t + 1
            if all(done):
                break
        comp = idx[:, P:]
        texts = [self.tok.decode(comp[k, :n_used[k]].tolist()).strip().split("\n")[0].strip()
                 for k in range(K)]
        return comp, n_used, texts

    def logp(self, pid, comp, n_used):
        K, L = comp.shape
        seq = torch.cat([pid[None].repeat(K, 1), comp], 1)[:, -self.m.T - 1:]
        with torch.autocast("cuda", torch.bfloat16):
            logits = self.m(seq[:, :-1])
        lp = F.log_softmax(logits.float()[:, -L:], -1).gather(2, comp[:, :, None]).squeeze(2)
        mask = torch.arange(L, device=comp.device)[None] < torch.tensor(n_used, device=comp.device)[:, None]
        return (lp * mask).sum(1)


def norm(t):
    return " ".join(t.split())


def skeleton(t):
    """Tactic names only: `norm_cast <;> grind [add_assoc]` -> `norm_cast grind`.
    Used as the diversity key so that padding a proof with irrelevant hints
    does not count as a new proof."""
    t = re.sub(r"\[[^\]]*\]", " ", t)
    return " ".join((piece.split() or [""])[0] for piece in re.split(r"<;>|;|·", t) if piece.strip())


def shape(texts, ok, div, novel, seen, key=norm):
    """Rewards for one group. div: a correct proof shares its unit reward with
    correct proofs in the group that have the same key (so the group's total is the
    number of distinct correct keys). novel: one-time bonus for a key never found
    before for this problem."""
    keys = [key(t) for t in texts]
    cnt = Counter(k for k, o in zip(keys, ok) if o)
    r = []
    for k, o in zip(keys, ok):
        v = 0.0
        if o:
            v = 1.0 / cnt[k] if div else 1.0
            if novel and k not in seen:
                v += novel / cnt[k]
        r.append(v)
    seen.update(cnt)
    return r


def evaluate(pol, probs, K):
    pol.m.eval()
    items, owner = [], []
    for i, p in enumerate(probs):
        _, _, texts = pol.sample(pol.prompt_ids(p["formal_statement"]), K)
        items += [(p["formal_statement"], t) for t in texts]
        owner += [i] * K
    ok = check_many(items)
    pol.m.train()
    solved, solved8 = {}, set()
    for j, ((_, t), i, o) in enumerate(zip(items, owner, ok)):
        if o:
            solved.setdefault(probs[i]["name"], set()).add(norm(t))
            if j % K < 8:
                solved8.add(probs[i]["name"])
    skel = Counter(skeleton(t) for v in solved.values() for t in v)
    return {"solved": len(solved), "n": len(probs), "pass@8": round(len(solved8) / len(probs), 4),
            f"pass@{K}": round(len(solved) / len(probs), 4),
            "solved_without_grind": sum(any("grind" not in t for t in v) for v in solved.values()),
            "distinct_proofs": sum(len(v) for v in solved.values()),
            "distinct_skeletons": sum(len({skeleton(t) for t in v}) for v in solved.values()),
            "skeletons": dict(skel.most_common(12)),
            "proofs": {k: sorted(v)[:4] for k, v in sorted(solved.items())}}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ckpt", required=True)
    ap.add_argument("--steps", type=int, default=100)
    ap.add_argument("--G", type=int, default=8)
    ap.add_argument("--K", type=int, default=16)
    ap.add_argument("--eval_K", type=int, default=16)
    ap.add_argument("--lr", type=float, default=2e-5)
    ap.add_argument("--anchor", type=float, default=0.0)
    ap.add_argument("--anchor_reward", default="log")
    ap.add_argument("--eval_every", type=int, default=50)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--div", action="store_true", help="share reward among identical correct proofs")
    ap.add_argument("--novel", type=float, default=0.0, help="bonus for a proof not found before")
    ap.add_argument("--div_key", default="text", choices=["text", "skeleton"],
                    help="what counts as the same proof for --div/--novel")
    ap.add_argument("--skip_eval0", action="store_true")
    ap.add_argument("--out", default="results/prove2.json")
    a = ap.parse_args()

    torch.manual_seed(a.seed)
    rng = random.Random(a.seed)
    model = GPT.load(a.ckpt)
    pol = Policy(model, Tokenizer.from_file("data_bpe/tokenizer.json"))
    probs = [p for p in json.load(open("data_minif2f/minif2f_checked.json")) if p["ok"]]
    train = [p for p in probs if p["split"] == "valid"]
    test = [p for p in probs if p["split"] == "test"]
    corpus = np.memmap("data_bpe/train.bin", dtype=np.uint16, mode="r") if a.anchor else None
    opt = torch.optim.AdamW(model.parameters(), lr=a.lr, weight_decay=0.0)

    log, t0, seen = [], time.time(), {}
    for step in range(a.steps + 1):
        if step % a.eval_every == 0 and (step or not a.skip_eval0):
            m = {"step": step, "min": round((time.time() - t0) / 60, 1), "test": evaluate(pol, test, a.eval_K)}
            log.append(m)
            print(json.dumps({k: v for k, v in m["test"].items() if k != "proofs"} | {"step": step, "min": m["min"]},
                             ensure_ascii=False), flush=True)
            if step == a.steps:
                break
        if step == a.steps:
            break
        batch = []
        for p in rng.sample(train, a.G):
            pid = pol.prompt_ids(p["formal_statement"])
            comp, n_used, texts = pol.sample(pid, a.K)
            batch.append((p, pid, comp, n_used, texts))
        items = [(p["formal_statement"], t) for p, _, _, _, texts in batch for t in texts]
        ok = check_many(items)
        r = torch.tensor([v for g, (p, _, _, _, texts) in enumerate(batch)
                          for v in shape(texts, ok[g * a.K:(g + 1) * a.K], a.div, a.novel,
                                         seen.setdefault(p["name"], set()),
                                         skeleton if a.div_key == "skeleton" else norm)],
                         dtype=torch.float, device="cuda").view(a.G, a.K)
        adv = r - r.mean(1, keepdim=True)
        loss = torch.zeros((), device="cuda")
        for g, (_, pid, comp, n_used, _) in enumerate(batch):
            if adv[g].abs().sum() > 0:
                loss = loss - (adv[g] * pol.logp(pid, comp, n_used)).mean() / a.G
        if a.anchor:
            o = np.random.randint(0, len(corpus) - model.T - 1, 8)
            w = torch.from_numpy(np.stack([corpus[i:i + model.T + 1].astype(np.int64) for i in o])).cuda()
            with torch.autocast("cuda", torch.bfloat16):
                lg = model(w[:, :-1])
            loss = loss - a.anchor * score(a.anchor_reward, lg, w[:, 1:]).mean()
        if loss.requires_grad:
            opt.zero_grad(set_to_none=True)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            opt.step()
        okt = torch.tensor(ok, dtype=torch.float).view(a.G, a.K)
        n_distinct = sum(len({norm(t) for t, o in zip(b[4], okt[g]) if o}) for g, b in enumerate(batch))
        print(f"step {step} pass {okt.mean().item():.3f} reward {r.mean().item():.3f} "
              f"distinct_correct {n_distinct} solved {int((okt.sum(1) > 0).sum())}/{a.G}", flush=True)
        json.dump({"args": vars(a), "log": log}, open(a.out, "w"), indent=1, ensure_ascii=False)
    json.dump({"args": vars(a), "log": log}, open(a.out, "w"), indent=1, ensure_ascii=False)


if __name__ == "__main__":
    main()
