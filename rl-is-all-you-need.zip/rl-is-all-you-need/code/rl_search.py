"""Multi-line proofs: best-first search over tactic steps with Lean goal states,
and RL from the verifier on the search traces (expert iteration).

Prompt for each step = statement + tactics so far + the current goal state as a
Lean comment. The policy samples k candidate next lines; Lean (lean_state.py)
returns proved / open(new goals) / error for each. Nodes are expanded in order of
cumulative log-probability; steps that leave the goal unchanged or revisit a
state are dropped.

RL: search on the miniF2F `valid` split, keep the (prompt, tactic) steps of the
proofs that Lean accepted (reward 1, everything else reward 0), and raise their
log-probability, with the stage-1 log-score reward on corpus text as an anchor.

Usage:
  python rl_search.py eval  --ckpt ckpt/bpe_log.pt --split test
  python rl_search.py train --ckpt ckpt/bpe_log.pt --rounds 2 --save ckpt/search_rl.pt
"""
import argparse
import heapq
import json
import time
from collections import Counter

import numpy as np
import torch
from tokenizers import Tokenizer

from gpt import GPT
from lean_state import run_states
from pretrain_bpe import score
from rl_prove2 import Policy


def prompt(stmt, tactics, goals, max_goal=700):
    g = goals if len(goals) <= max_goal else goals[:max_goal] + " …"
    g = g.replace("-/", "- /")
    return (stmt.rstrip() + "\n" + "".join(f"  {t}\n" for t in tactics)
            + "  /- goal:\n" + "\n".join("  " + l for l in g.splitlines()) + " -/")


CLOSERS = ["grind", "nlinarith", "omega", "linarith", "ring_nf", "aesop", "norm_num", "decide", "simp", "positivity"]
CLOSER_LP = -3.0     # prior log-probability assigned to a closer step that only makes progress


@torch.no_grad()
def search(pol, probs, k=8, max_exp=8, max_depth=6, temp=1.0, closers=(), log=print):
    """Batched best-first search. Returns {name: {...}} for every problem.
    `closers` are fixed automation tactics tried at every expanded node in
    addition to the k policy samples (hybrid search)."""
    pol.m.eval()
    roots = run_states([(p["formal_statement"], []) for p in probs])
    out = {p["name"]: {"proof": None, "calls": 1, "steps": []} for p in probs}
    frontier, seen, tick = {}, {}, 0
    for i, (st, g) in enumerate(roots):
        if st == "open":
            frontier[i] = [(0.0, tick, [], g, [])]   # (-score, tiebreak, tactics, goals, prompts)
            seen[i] = {g}
    for e in range(max_exp):
        active = [i for i in frontier if frontier[i] and out[probs[i]["name"]]["proof"] is None]
        if not active:
            break
        reqs = []
        for i in active:
            negs, _, tacs, goals, prompts = heapq.heappop(frontier[i])
            ptxt = prompt(probs[i]["formal_statement"], tacs, goals)
            texts, lps = [], []
            if k > 0:                       # k = 0: closer-only search (no model), a baseline
                pid = pol.prompt_ids(ptxt)
                comp, n_used, texts = pol.sample(pid, k, temp=temp)
                lps = pol.logp(pid, comp, n_used).tolist()
            uniq = {}
            for t, lp in zip(texts, lps):
                if t and t not in uniq:
                    uniq[t] = (lp, "policy")
            for c in closers:
                uniq.setdefault(c, (CLOSER_LP, "closer"))
            for t, (lp, src) in uniq.items():
                reqs.append((i, -negs + lp, tacs, t, prompts + [ptxt], goals, src))
        res = run_states([(probs[i]["formal_statement"], tacs + [t]) for i, _, tacs, t, _, _, _ in reqs])
        for (i, sc, tacs, t, prompts, parent_goals, src), (st, g) in zip(reqs, res):
            rec = out[probs[i]["name"]]
            rec["calls"] += 1
            if rec["proof"] is not None:
                continue
            srcs = rec.setdefault("_src", {})
            path_src = srcs.get(tuple(tacs), []) + [src]
            if st == "proved":
                rec["proof"] = tacs + [t]
                rec["sources"] = path_src
                rec["steps"] = list(zip(prompts, tacs + [t]))
            elif st == "open" and g not in seen[i] and g != parent_goals and len(tacs) + 1 < max_depth:
                seen[i].add(g)
                srcs[tuple(tacs + [t])] = path_src
                tick += 1
                heapq.heappush(frontier[i], (-sc, tick, tacs + [t], g, prompts))
        n = sum(r["proof"] is not None for r in out.values())
        log(f"  expansion {e + 1}/{max_exp}: active {len(active)}, lean calls {len(reqs)}, solved {n}/{len(probs)}")
    pol.m.train()
    for rec in out.values():
        rec.pop("_src", None)
    return out


def union_baseline(split):
    """Problems solved by the 10-tactic union baseline (grind + 9 single tactics)."""
    base = json.load(open("data_minif2f/single_tactic_solved.json"))
    try:
        grind = set(json.load(open("data_minif2f/grind_solved.json")))
    except FileNotFoundError:
        grind = set()
    return set(base) | grind


def summarize(out):
    solved = {k: v["proof"] for k, v in out.items() if v["proof"]}
    lens = Counter(len(p) for p in solved.values())
    union = union_baseline(None)
    beyond = sorted(k for k in solved if k not in union)
    used_policy = sorted(k for k, v in out.items() if v["proof"] and "policy" in v.get("sources", []))
    return {"solved": len(solved), "n": len(out), "rate": round(len(solved) / len(out), 4),
            "beyond_union": len(beyond), "beyond_union_names": beyond,
            "uses_policy_step": len(used_policy),
            "mean_calls": round(sum(v["calls"] for v in out.values()) / len(out), 1),
            "proof_lengths": dict(sorted(lens.items())),
            "proofs": {k: {"proof": v["proof"], "sources": v.get("sources")} for k, v in out.items() if v["proof"]}}


def train_on(pol, steps, corpus, anchor, epochs=3, lr=2e-5, bs=16):
    """Reward-1 steps get their log-probability raised (reward-0 samples contribute nothing)."""
    opt = torch.optim.AdamW(pol.m.parameters(), lr=lr, weight_decay=0.0)
    tok = pol.tok
    data = []
    for ptxt, tac in steps:
        pid = pol.prompt_ids(ptxt)
        tgt = tok.encode("\n  " + tac + "\n").ids
        data.append((pid, torch.tensor(tgt, device="cuda")))
    for ep in range(epochs):
        order = np.random.permutation(len(data))
        for b in range(0, len(order), bs):
            loss = torch.zeros((), device="cuda")
            for j in order[b:b + bs]:
                pid, tgt = data[j]
                seq = torch.cat([pid, tgt])[-pol.m.T - 1:][None]
                with torch.autocast("cuda", torch.bfloat16):
                    lg = pol.m(seq[:, :-1])
                lp = torch.log_softmax(lg.float()[0, -len(tgt):], -1).gather(1, tgt[:, None]).sum()
                loss = loss - lp / len(order[b:b + bs])
            if anchor:
                o = np.random.randint(0, len(corpus) - pol.m.T - 1, 8)
                w = torch.from_numpy(np.stack([corpus[i:i + pol.m.T + 1].astype(np.int64) for i in o])).cuda()
                with torch.autocast("cuda", torch.bfloat16):
                    lg = pol.m(w[:, :-1])
                loss = loss - anchor * score("log", lg, w[:, 1:]).mean()
            opt.zero_grad(set_to_none=True)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(pol.m.parameters(), 1.0)
            opt.step()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("mode", choices=["eval", "train"])
    ap.add_argument("--ckpt", default="ckpt/bpe_log.pt")
    ap.add_argument("--split", default="test")
    ap.add_argument("--k", type=int, default=8)
    ap.add_argument("--max_exp", type=int, default=8)
    ap.add_argument("--max_depth", type=int, default=6)
    ap.add_argument("--rounds", type=int, default=2)
    ap.add_argument("--anchor", type=float, default=0.5)
    ap.add_argument("--save", default="")
    ap.add_argument("--out", default="results/search.json")
    ap.add_argument("--limit", type=int, default=0, help="first N problems only (smoke tests)")
    ap.add_argument("--closers", action="store_true", help="also try the fixed automation tactics at each node")
    a = ap.parse_args()

    torch.manual_seed(0)
    np.random.seed(0)
    pol = Policy(GPT.load(a.ckpt), Tokenizer.from_file("data_bpe/tokenizer.json"))
    probs = [p for p in json.load(open("data_minif2f/minif2f_checked.json")) if p["ok"]]
    split = lambda s: [p for p in probs if p["split"] == s][: a.limit or None]
    t0 = time.time()
    report = {"args": vars(a)}

    if a.mode == "eval":
        out = search(pol, split(a.split), a.k, a.max_exp, a.max_depth, closers=CLOSERS if a.closers else ())
        report["eval"] = summarize(out)
    else:
        corpus = np.memmap("data_bpe/train.bin", dtype=np.uint16, mode="r")
        train, steps = split("valid"), {}
        report["rounds"] = []
        for r in range(a.rounds):
            print(f"round {r + 1}: searching {len(train)} valid problems", flush=True)
            out = search(pol, train, a.k, a.max_exp, a.max_depth, closers=CLOSERS if a.closers else ())
            for name, rec in out.items():
                if rec["proof"]:
                    steps[name] = rec["steps"]          # keep the latest proof per problem
            s = summarize(out)
            report["rounds"].append({k: v for k, v in s.items() if k != "proofs"} | {"min": round((time.time() - t0) / 60, 1)})
            flat = [st for v in steps.values() for st in v]
            print(f"round {r + 1}: solved {s['solved']}/{s['n']}, training on {len(flat)} steps "
                  f"from {len(steps)} proofs", flush=True)
            train_on(pol, flat, corpus, a.anchor)
        if a.save:
            torch.save({"cfg": pol.m.cfg, "state": pol.m.state_dict()}, a.save)
        report["train_proofs"] = {k: [t for _, t in v] for k, v in steps.items()}
    report["min"] = round((time.time() - t0) / 60, 1)
    json.dump(report, open(a.out, "w"), indent=1, ensure_ascii=False)
    print(json.dumps({k: v for k, v in report.get("eval", {}).items() if k != "proofs"}), flush=True)


if __name__ == "__main__":
    main()
