"""Run proof prefixes through Lean + Mathlib and report the resulting goal state.

Each item is (statement ending in `by`, [tactic lines]). Result per item:
  ("proved", "")         no errors: the tactics close every goal
  ("open", goals_text)   only an `unsolved goals` error: goals_text is Lean's goal display
  ("error", message)     some tactic failed, or the text could not be checked
Many items share one Lean process (one `import Mathlib`); messages are mapped
back to items by line range, as in mathlib_verify.py.
"""
import json
import os
import subprocess
import tempfile
from concurrent.futures import ThreadPoolExecutor

from mathlib_verify import HEADER, LAKE, NAME, PROJECT, safe

_CACHE = {}


def _block(i, stmt, tactics):
    stmt = NAME.sub(lambda m: f"{m.group(1)} st_{i}_{m.group(2)}", stmt.strip(), count=1)
    body = "".join(f"  {t}\n" for t in tactics) if tactics else "  skip\n"
    return f"{stmt}\n{body}\n"


def _run_file(items, timeout):
    parts, ranges, row = [HEADER], [], HEADER.count("\n") + 1
    for i, (stmt, tacs) in enumerate(items):
        b = _block(i, stmt, tacs)
        n = b.count("\n")
        ranges.append((row, row + n - 1))
        parts.append(b)
        row += n
    with tempfile.NamedTemporaryFile("w", suffix=".lean", delete=False, dir="/tmp") as f:
        f.write("".join(parts))
        path = f.name
    try:
        r = subprocess.run([LAKE, "env", "lean", "--json", path], cwd=PROJECT,
                           capture_output=True, text=True, timeout=timeout)
    except subprocess.TimeoutExpired:
        return [("error", "timeout")] * len(items)
    finally:
        os.unlink(path)
    msgs = [[] for _ in items]
    for ln in r.stdout.splitlines():
        try:
            m = json.loads(ln)
        except json.JSONDecodeError:
            continue
        sev, text, line = m.get("severity"), m.get("data", ""), m.get("pos", {}).get("line", 0)
        if sev != "error" and "sorry" not in text:
            continue
        hit = [k for k, (a, b) in enumerate(ranges) if a <= line <= b]
        if not hit:
            return [("error", "message outside candidates: " + text[:200])] * len(items)
        k = hit[0]
        msgs[k].append(text)
        if line == ranges[k][0] and k > 0 and ("unexpected" in text or "expected" in text):
            msgs[k - 1].append("spill: " + text)
    out = []
    for (stmt, tacs), ms in zip(items, msgs):
        if not ms:
            out.append(("proved", "") if tacs else ("error", "empty proof closed the goal?"))
        elif all(t.startswith("unsolved goals") for t in ms) and len(ms) == 1:
            out.append(("open", ms[0][len("unsolved goals"):].strip()))
        else:
            out.append(("error", ms[0][:300]))
    return out


def run_states(items, per_file=16, workers=8, timeout=900):
    keys = [(s, tuple(" ".join(t.split()) for t in tacs)) for s, tacs in items]
    todo, first = [], set()
    for i, (k, (_, tacs)) in enumerate(zip(keys, items)):
        if k in _CACHE or k in first:
            continue
        if not all(safe(t) for t in tacs):
            _CACHE[k] = ("error", "unsafe tactic")
            continue
        first.add(k)
        todo.append(i)
    chunks = [todo[j:j + per_file] for j in range(0, len(todo), per_file)]
    with ThreadPoolExecutor(workers) as ex:
        for chunk, res in zip(chunks, ex.map(lambda c: _run_file([items[i] for i in c], timeout), chunks)):
            for i, o in zip(chunk, res):
                _CACHE[keys[i]] = o
    return [_CACHE[k] for k in keys]


if __name__ == "__main__":
    s = "theorem t (a b : ℝ) (h₀ : a + b = 3) (h₁ : a - b = 1) : a = 2 := by"
    tests = [[], ["have h : 2 * a = 4 := by linarith"], ["have h : 2 * a = 4 := by linarith", "linarith"],
             ["norm_num at h₀"], ["exact foo"], ["intro x"], ["linarith"]]
    for t, r in zip(tests, run_states([(s, t) for t in tests])):
        print(t, "->", r[0], "|", r[1][:160].replace("\n", " / "))
