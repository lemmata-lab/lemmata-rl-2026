#!/bin/bash
# Stage 2: RL from the Lean verifier, starting from the pure-RL stage-1 checkpoint.
# Usage: bash run_prove.sh [steps]
cd "$(dirname "$0")"
PY=${PY:-python3}
S=${1:-200}
$PY rl_prove.py --ckpt ckpt/lean_pg32.pt --steps $S --anchor 0   --out results/prove_anchor0.json   > results/prove_anchor0.log 2>&1 &
$PY rl_prove.py --ckpt ckpt/lean_pg32.pt --steps $S --anchor 0.5 --out results/prove_anchor0.5.json > results/prove_anchor0.5.log 2>&1 &
wait
grep -h -v -i warn results/prove_anchor0.log | grep pass | tail -1
grep -h -v -i warn results/prove_anchor0.5.log | grep pass | tail -1
