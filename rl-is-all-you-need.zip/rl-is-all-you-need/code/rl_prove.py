"""Stage 2: reinforcement learning from the Lean verifier.

Starts from a checkpoint trained by rlgpt.py on the Lean corpus (stage 1, which
can itself be pure RL with the fair Brier reward). For each generated theorem
statement the model samples K one-line tactic proofs; Lean checks them; the
reward is 1 if the proof is accepted. Advantages are group-normalised (GRPO
style). Optionally the stage-1 fair Brier reward on corpus text is kept as an
anchor (--anchor λ) so the policy does not collapse onto a few tactics.

Usage: python rl_prove.py --ckpt lean_pg.pt [--steps 150] [--anchor 0.5]
"""
import argparse
import json
import random
import time

import torch
import torch.nn.functional as F

from lean_verify import check_many
from rlgpt import GPT, Text, objective

NAMES = ["p", "q", "r", "s", "P", "Q", "R", "A", "B", "C"]
HYPS = ["h", "h1", "h2", "hp", "hq", "hA", "hB", "ha", "hb", "H"]
NATS = ["a", "b", "c", "n", "m", "k", "x", "y"]


def make_goal(rng, kind=None):
    """Random core-Lean goal: (template name, statement text)."""
    p, q, r = rng.sample(NAMES, 3)
    h1, h2, h3 = rng.sample(HYPS, 3)
    a, b = rng.sample(NATS, 2)
    i, j = rng.randint(2, 60), rng.randint(2, 60)
    props = f"({p} {q} {r} : Prop)"
    T = {
        "and_intro": f"{props} ({h1} : {p}) ({h2} : {q}) : {p} ∧ {q}",
        "and_left": f"{props} ({h1} : {p} ∧ {q}) : {p}",
        "and_right": f"{props} ({h1} : {p} ∧ {q}) : {q}",
        "or_left": f"{props} ({h1} : {p}) : {p} ∨ {q}",
        "or_right": f"{props} ({h1} : {q}) : {p} ∨ {q}",
        "imp_id": f"{props} : {p} → {p}",
        "mp": f"{props} ({h1} : {p} → {q}) ({h2} : {p}) : {q}",
        "and_comm": f"{props} ({h1} : {p} ∧ {q}) : {q} ∧ {p}",
        "imp_trans": f"{props} ({h1} : {p} → {q}) ({h2} : {q} → {r}) : {p} → {r}",
        "nat_comm": f"({a} {b} : Nat) : {a} + {b} = {b} + {a}",
        "nat_lt": f"({a} {b} : Nat) ({h1} : {a} ≤ {b}) : {a} < {b} + 1",
        "numeral": f": {i} + {j} = {i + j}",
    }
    kind = kind or rng.choice(list(T))
    return kind, f"theorem t {T[kind]} := by\n  "


def encode(s, stoi, dev):
    return torch.tensor([stoi[c] for c in s], device=dev)


@torch.no_grad()
def sample_proofs(model, prompt_ids, K, max_len=60, temp=1.0, nl=None):
    """K completions of one prompt, stopped at the first newline."""
    idx = prompt_ids.repeat(K, 1)
    P = idx.size(1)
    done = torch.zeros(K, dtype=torch.bool, device=idx.device)
    for _ in range(max_len):
        logits = model(idx[:, -model.T:])[:, -1] / temp
        nxt = torch.multinomial(F.softmax(logits.float(), -1), 1)
        nxt[done] = nl
        idx = torch.cat([idx, nxt], 1)
        done |= nxt.squeeze(1) == nl
        if done.all():
            break
    return idx[:, P:]


def completion_logp(model, prompt_ids, comp, nl):
    """Sum of log-probs of each completion up to and including its first newline."""
    K = comp.size(0)
    seq = torch.cat([prompt_ids.repeat(K, 1), comp], 1)[:, -model.T - 1:]
    L = comp.size(1)
    logp = F.log_softmax(model(seq[:, :-1]).float(), -1)[:, -L:]
    tok = logp.gather(2, comp[:, :, None]).squeeze(2)
    is_nl = (comp == nl).int()
    mask = (is_nl.cumsum(1) - is_nl) == 0                      # up to first newline
    return (tok * mask).sum(1)


def decode_proof(comp_row, chars, nl):
    s = []
    for t in comp_row.tolist():
        if t == nl:
            break
        s.append(chars[t])
    return "".join(s)


def evaluate(model, goals, chars, stoi, dev, K=8):
    model.eval()
    nl = stoi["\n"]
    srcs, meta = [], []
    for kind, stmt in goals:
        comp = sample_proofs(model, encode(stmt, stoi, dev)[None], K, nl=nl)
        for row in comp:
            pr = decode_proof(row, chars, nl)
            srcs.append(stmt + pr + "\n")
            meta.append((kind, pr))
    ok = check_many(srcs)
    model.train()
    by = {}
    for (kind, pr), o in zip(meta, ok):
        by.setdefault(kind, []).append(o)
    pass1 = sum(ok) / len(ok)
    passK = sum(any(ok[i * K:(i + 1) * K]) for i in range(len(goals))) / len(goals)
    proofs = sorted({pr for (_, pr), o in zip(meta, ok) if o})
    return {"pass@1": pass1, f"pass@{K}": passK,
            "per_kind": {k: round(sum(v) / len(v), 2) for k, v in sorted(by.items())},
            "n_distinct_correct": len(proofs), "examples": proofs[:12]}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ckpt", required=True)
    ap.add_argument("--corpus", default="lean_corpus.txt")
    ap.add_argument("--steps", type=int, default=150)
    ap.add_argument("--G", type=int, default=8, help="goals per step")
    ap.add_argument("--K", type=int, default=8, help="proof samples per goal")
    ap.add_argument("--lr", type=float, default=1e-4)
    ap.add_argument("--anchor", type=float, default=0.0, help="weight of fair-Brier corpus reward")
    ap.add_argument("--eval_every", type=int, default=50)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--out", default="results/prove.json")
    a = ap.parse_args()

    dev = "cuda"
    torch.manual_seed(a.seed)
    ck = torch.load(a.ckpt, map_location=dev)
    c = ck["cfg"]
    model = GPT(c["V"], c["T"], c["d"], c["L"], c["h"]).to(dev)
    model.load_state_dict(ck["state"])
    chars = ck["chars"]
    stoi = {ch: i for i, ch in enumerate(chars)}
    nl = stoi["\n"]
    corpus = Text(a.corpus, dev) if a.anchor else None
    opt = torch.optim.AdamW(model.parameters(), lr=a.lr, weight_decay=0.0)

    rng_train, rng_test = random.Random(a.seed), random.Random(12345)
    test_goals = [make_goal(rng_test) for _ in range(48)]
    log, t0 = [], time.time()
    for step in range(a.steps + 1):
        if step % a.eval_every == 0:
            m = evaluate(model, test_goals, chars, stoi, dev) | {"step": step, "sec": round(time.time() - t0)}
            log.append(m)
            print(json.dumps(m, ensure_ascii=False), flush=True)
        if step == a.steps:
            break
        # ---- verifier reward
        goals = [make_goal(rng_train) for _ in range(a.G)]
        batch = []
        for kind, stmt in goals:
            pid = encode(stmt, stoi, dev)[None]
            comp = sample_proofs(model, pid, a.K, nl=nl)
            batch.append((stmt, pid, comp))
        srcs = [stmt + decode_proof(r, chars, nl) + "\n" for stmt, _, comp in batch for r in comp]
        rewards = torch.tensor(check_many(srcs), dtype=torch.float, device=dev).view(a.G, a.K)
        adv = rewards - rewards.mean(1, keepdim=True)            # group baseline
        loss = 0.0
        for g, (_, pid, comp) in enumerate(batch):
            if adv[g].abs().sum() > 0:
                loss = loss - (adv[g] * completion_logp(model, pid, comp, nl)).mean() / a.G
        # ---- anchor: stage-1 fair Brier reward on corpus text (still pure RL)
        if a.anchor:
            inp, tgt = corpus.batch(32, c["T"])
            loss = loss + a.anchor * objective("pg", model(inp).reshape(-1, c["V"]), tgt.reshape(-1), K=8)
        if torch.is_tensor(loss):
            opt.zero_grad(set_to_none=True)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            opt.step()
        if step % 10 == 0:
            print(f"step {step} train_reward {rewards.mean().item():.3f}", flush=True)
    json.dump({"args": vars(a), "log": log}, open(a.out, "w"), indent=1, ensure_ascii=False)


if __name__ == "__main__":
    main()
