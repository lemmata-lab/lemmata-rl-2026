#!/bin/bash
# Ablations against policy collapse on miniF2F (all from ckpt/bpe_log.pt, 60 RL steps,
# final eval on test with 16 samples), 2 seeds each, 3 runs in parallel (8 Lean workers each).
# Usage: bash run_collapse.sh [steps]
cd "$(dirname "$0")"
PY=${PY:-python3}
S=${1:-60}
run() {  # name, extra args
  $PY rl_prove2.py --ckpt ckpt/bpe_log.pt --steps $S --eval_every $S --skip_eval0 \
    --eval_K 16 --out results/collapse_$1.json "${@:2}" 2>&1 | grep -v -i warn > results/collapse_$1.log
}
# step-0 policy (no RL): eval only
$PY rl_prove2.py --ckpt ckpt/bpe_log.pt --steps 0 --eval_every 1 --eval_K 16 \
  --out results/collapse_base.json 2>&1 | grep -v -i warn > results/collapse_base.log &
jobs=()
for seed in 0 1; do
  jobs+=("E_control_s$seed --anchor 0.5 --K 16 --seed $seed")
  jobs+=("A_anchor2_s$seed --anchor 2.0 --K 16 --seed $seed")
  jobs+=("C_div_s$seed --anchor 0.5 --K 16 --div --novel 0.5 --seed $seed")
  jobs+=("B_K32_s$seed --anchor 0.5 --K 32 --seed $seed")
  jobs+=("D_all_s$seed --anchor 2.0 --K 32 --div --novel 0.5 --seed $seed")
done
i=0
for j in "${jobs[@]}"; do
  run $j &
  i=$((i + 1))
  if (( i % 3 == 0 )); then wait; fi
done
wait
for f in results/collapse_*.log; do echo "$f: $(grep '"step"' $f | cut -c1-300)"; done
