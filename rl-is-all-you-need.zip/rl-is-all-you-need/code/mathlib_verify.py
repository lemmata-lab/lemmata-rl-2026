"""Batch proof checker against Mathlib (the stage-2 reward at miniF2F scale).

Candidates are one-line tactic scripts. Each batch becomes one Lean file with
`import Mathlib`, one renamed theorem per candidate; Lean's JSON messages are
mapped back to candidates by line range. A candidate is accepted iff its
theorem has no error and no `sorry` warning. Candidates that could escape their
own theorem (comments, strings, commands, newlines) are rejected up front.
"""
import json
import os
import re
import shutil
import subprocess
import tempfile
from concurrent.futures import ThreadPoolExecutor

# Lake project with Mathlib v4.34.1 built (default: ../lean in this repository).
PROJECT = os.path.abspath(os.environ.get(
    "MATHLIB_PROJECT", os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "lean")))
LAKE = os.environ.get("LAKE") or shutil.which("lake") or os.path.expanduser("~/.elan/bin/lake")
HEADER = ("import Mathlib\nimport Aesop\nset_option maxHeartbeats 400000\n"
          "open BigOperators Real Nat Topology Rat\n\n")
BAD = re.compile(r'sorry|admit|native_decide|--|/-|-/|"|«|»|\w\?|\bdecreasing_by\b|'
                 r'\b(theorem|lemma|def|axiom|instance|example|namespace|section|end|open|'
                 r'set_option|attribute|variable|macro|elab|syntax|notation|import)\b|#|\n')
NAME = re.compile(r"^(theorem|lemma)\s+(\S+)")


def safe(tactic):
    return re.search(r"\w", tactic) is not None and not BAD.search(tactic)


def _run_file(items, timeout):
    """items: list of (statement, tactic). Returns list of bools."""
    lines, ranges = [HEADER], []
    row = HEADER.count("\n") + 1
    for i, (stmt, tac) in enumerate(items):
        stmt = NAME.sub(lambda m: f"{m.group(1)} cand_{i}_{m.group(2)}", stmt.strip(), count=1)
        if not stmt.endswith("by"):
            stmt = stmt.rstrip() + " by" if stmt.rstrip().endswith(":=") else stmt
        block = f"{stmt}\n  {tac if tac is not None else 'sorry'}\n\n"
        n = block.count("\n")
        ranges.append((row, row + n - 1))
        lines.append(block)
        row += n
    with tempfile.NamedTemporaryFile("w", suffix=".lean", delete=False, dir="/tmp") as f:
        f.write("".join(lines))
        path = f.name
    try:
        r = subprocess.run([LAKE, "env", "lean", "--json", path], cwd=PROJECT,
                           capture_output=True, text=True, timeout=timeout)
        out = r.stdout
    except subprocess.TimeoutExpired:
        return [False] * len(items)
    finally:
        os.unlink(path)
    bad = [False] * len(items)
    header_error = False
    for ln in out.splitlines():
        try:
            m = json.loads(ln)
        except json.JSONDecodeError:
            continue
        sev, text, line = m.get("severity"), m.get("data", ""), m.get("pos", {}).get("line", 0)
        if sev != "error" and "sorry" not in text:
            continue
        hit = [k for k, (a, b) in enumerate(ranges) if a <= line <= b]
        if hit:
            k = hit[0]
            bad[k] = True
            # An error on a theorem's own first line can only come from the previous
            # candidate's proof spilling over (statements are pre-checked), so blame both.
            if line == ranges[k][0] and k > 0 and ("unexpected" in text or "expected" in text):
                bad[k - 1] = True
        else:
            header_error = True                  # before the first or after the last candidate
    if header_error or (r.returncode != 0 and not any(bad)):
        return [False] * len(items)
    return [not b for b in bad]


_CACHE = {}


def check_many(items, per_file=16, workers=8, timeout=600):
    """items: list of (statement, tactic). Unsafe tactics fail without calling Lean.
    Results are cached per process (Lean is deterministic for a fixed Mathlib)."""
    key = [(s, " ".join(t.split())) if t is not None else (s, None) for s, t in items]
    ok = [_CACHE.get(k, False) for k in key]
    todo, first = [], {}
    for i, (k, (_, t)) in enumerate(zip(key, items)):
        if k in _CACHE or not (t is None or safe(t)):
            continue
        if k in first:
            continue
        first[k] = i
        todo.append(i)
    chunks = [todo[k:k + per_file] for k in range(0, len(todo), per_file)]
    with ThreadPoolExecutor(workers) as ex:
        for chunk, res in zip(chunks, ex.map(lambda c: _run_file([items[i] for i in c], timeout), chunks)):
            for i, o in zip(chunk, res):
                _CACHE[key[i]] = o
    return [_CACHE.get(k, False) if (t is None or safe(t)) else False for k, (_, t) in zip(key, items)]


def elaborates(statements, **kw):
    """Which statements elaborate in this Mathlib (checked with `sorry`, expecting only the sorry warning)."""
    items = [(s, None) for s in statements]
    out = [True] * len(items)
    chunks = [list(range(k, min(k + 32, len(items)))) for k in range(0, len(items), 32)]

    def run(c):
        lines, ranges, row = [HEADER], [], HEADER.count("\n") + 1
        for i in c:
            st = NAME.sub(lambda m: f"{m.group(1)} cand_{i}_{m.group(2)}", statements[i].strip(), count=1)
            block = f"{st}\n  sorry\n\n"
            ranges.append((row, row + block.count("\n") - 1))
            lines.append(block)
            row += block.count("\n")
        with tempfile.NamedTemporaryFile("w", suffix=".lean", delete=False, dir="/tmp") as f:
            f.write("".join(lines))
            p = f.name
        r = subprocess.run([LAKE, "env", "lean", "--json", p], cwd=PROJECT, capture_output=True, text=True)
        os.unlink(p)
        bad = set()
        for ln in r.stdout.splitlines():
            try:
                m = json.loads(ln)
            except json.JSONDecodeError:
                continue
            if m.get("severity") == "error":
                line = m.get("pos", {}).get("line", 0)
                bad |= {c[k] for k, (a, b) in enumerate(ranges) if a <= line <= b}
        return bad

    with ThreadPoolExecutor(kw.get("workers", 8)) as ex:
        for bad in ex.map(run, chunks):
            for i in bad:
                out[i] = False
    return out


if __name__ == "__main__":
    import time
    probs = [json.loads(l) for l in open("data_minif2f/minif2f.jsonl")]
    t = time.time()
    ok = elaborates([p["formal_statement"] for p in probs])
    print(f"elaborate check: {sum(ok)}/{len(ok)} statements OK in {time.time() - t:.0f}s")
    keep = [dict(p, ok=o) for p, o in zip(probs, ok)]
    json.dump(keep, open("data_minif2f/minif2f_checked.json", "w"), ensure_ascii=False, indent=0)
    # baseline: single automation tactics, the floor an RL policy must beat
    tacs = ["norm_num", "simp", "omega", "linarith", "nlinarith", "decide", "ring_nf", "positivity", "aesop"]
    good = [p for p in keep if p["ok"]]
    t = time.time()
    items = [(p["formal_statement"], tac) for p in good for tac in tacs]
    res = check_many(items)
    solved = {}
    for (p, tac), r in zip([(p, tac) for p in good for tac in tacs], res):
        if r:
            solved.setdefault(p["name"], []).append(tac)
    for split in ("valid", "test"):
        n = [p for p in good if p["split"] == split]
        s = [p for p in n if p["name"] in solved]
        print(f"{split}: {len(s)}/{len(n)} solved by some single automation tactic")
    print("per tactic:", {t_: sum(t_ in v for v in solved.values()) for t_ in tacs})
    json.dump(solved, open("data_minif2f/single_tactic_solved.json", "w"), indent=0)
    # `grind` alone; together with the nine tactics above this is the ten-tactic union baseline
    ok = check_many([(p["formal_statement"], "grind") for p in good])
    grind = sorted(p["name"] for p, o in zip(good, ok) if o)
    json.dump(grind, open("data_minif2f/grind_solved.json", "w"), indent=0)
    for split in ("valid", "test"):
        n = [p for p in good if p["split"] == split]
        u = [p for p in n if p["name"] in solved or p["name"] in grind]
        print(f"{split}: {len(u)}/{len(n)} solved by the ten-tactic union (with grind)")
    print(f"{len(items)} checks in {time.time() - t:.0f}s")
