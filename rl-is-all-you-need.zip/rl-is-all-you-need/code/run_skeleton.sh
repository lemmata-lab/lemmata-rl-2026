#!/bin/bash
# Follow-up to run_collapse.sh: diversity/novelty measured on the tactic skeleton
# (hint lists stripped), closing the "grind [irrelevant_lemma]" loophole.
cd "$(dirname "$0")"
PY=${PY:-python3}
S=${1:-60}
run() {
  $PY rl_prove2.py --ckpt ckpt/bpe_log.pt --steps $S --eval_every $S --skip_eval0 \
    --eval_K 16 --div --novel 0.5 --div_key skeleton --out results/collapse_$1.json "${@:2}" 2>&1 \
    | grep -v -i warn > results/collapse_$1.log
}
run F_skel_all_s0 --anchor 2.0 --K 32 --seed 0 &
run F_skel_all_s1 --anchor 2.0 --K 32 --seed 1 &
run G_skel_K16_s0 --anchor 0.5 --K 16 --seed 0 &
wait
for f in results/collapse_[FG]_*.log; do echo "$f: $(grep '"step"' $f | sed 's/"proofs.*//' | cut -c1-400)"; done
