#!/bin/bash
# Char-level English text (corpus.txt from make_corpus.sh). Usage: bash run_text.sh [steps] [outdir]
cd "$(dirname "$0")"
PY=${PY:-python3}
S=${1:-5000}
O=${2:-results}
[ -f corpus.txt ] || bash make_corpus.sh
COMMON="--data text --text corpus.txt --T 128 --d 192 --L 4 --heads 6 --drop 0.1 --steps $S --eval_every $((S / 10))"
for args in "--method ntp" "--method brier" "--method pg --K 8" "--method pg --K 32" "--method pg1 --beta 0.05"; do
  $PY rlgpt.py $COMMON $args --out $O | grep -v '^$' | tail -12
  echo
done
