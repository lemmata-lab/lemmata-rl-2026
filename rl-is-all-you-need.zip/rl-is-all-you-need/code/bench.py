"""Per-step wall time and peak GPU memory of each training signal.

Methods are interleaved over several rounds so that background GPU load affects
all of them alike; the median over rounds is reported.
Usage: python bench.py
"""
import statistics
import time

import torch

import gpt
import rlgpt
from pretrain_bpe import score

dev = "cuda"


def bench(model, V, T, B, step_fn, n=20):
    opt = torch.optim.AdamW(model.parameters(), lr=1e-4)
    inp = torch.randint(V, (B, T), device=dev)
    tgt = torch.randint(V, (B, T), device=dev)
    for i in range(n + 3):
        if i == 3:
            torch.cuda.synchronize()
            torch.cuda.reset_peak_memory_stats()
            t = time.time()
        loss = step_fn(model, inp, tgt)
        opt.zero_grad(set_to_none=True)
        loss.backward()
        opt.step()
    torch.cuda.synchronize()
    return (time.time() - t) / n * 1000, torch.cuda.max_memory_allocated() / 2**20


def char_fn(method, K):
    def f(model, inp, tgt):
        lg = model(inp)
        return rlgpt.objective(method, lg.reshape(-1, lg.size(-1)), tgt.reshape(-1), K)
    return f


def bpe_fn(method, K):
    def f(model, inp, tgt):
        with torch.autocast("cuda", torch.bfloat16):
            lg = model(inp)
        if method in ("log", "brier"):
            return -score(method, lg, tgt).mean()
        return rlgpt.objective("pg", lg.float().reshape(-1, lg.size(-1)), tgt.reshape(-1), K)
    return f


setups = {
    "char (Lean corpus config: V=313, d=256, L=6, T=128, B=64)": (
        lambda: rlgpt.GPT(313, 128, 256, 6, 8).to(dev), 313, 128, 64,
        [("ntp", char_fn("ntp", 1)), ("brier", char_fn("brier", 1)),
         ("pg K=8", char_fn("pg", 8)), ("pg K=32", char_fn("pg", 32)), ("pg K=128", char_fn("pg", 128))]),
    "BPE (V=8192, d=512, L=8, T=512, B=32)": (
        lambda: gpt.GPT(8192, 512, 512, 8, 8).to(dev), 8192, 512, 32,
        [("log (=NTP)", bpe_fn("log", 1)), ("brier", bpe_fn("brier", 1)),
         ("pg K=8", bpe_fn("pg", 8)), ("pg K=64", bpe_fn("pg", 64))]),
}

for title, (mk, V, T, B, methods) in setups.items():
    times = {m: [] for m, _ in methods}
    mems = {}
    for rnd in range(3):
        for m, fn in methods:
            torch.manual_seed(0)
            model = mk()
            ms, mb = bench(model, V, T, B, fn)
            times[m].append(ms)
            mems[m] = mb
            del model
            torch.cuda.empty_cache()
    base = statistics.median(times[methods[0][0]])
    print(f"\n== {title}")
    print(f"{'method':12} {'ms/step':>8} {'x NTP':>6} {'peak MiB':>9}")
    for m, _ in methods:
        t = statistics.median(times[m])
        print(f"{m:12} {t:8.1f} {t / base:6.2f} {mems[m]:9.0f}")
