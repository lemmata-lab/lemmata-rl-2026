#!/bin/bash
# BPE-scale pretraining on all of Mathlib (paper Section 6, Fig. 1 right, Table 3).
# Builds data_bpe/ if missing, then trains with the log-score reward (= NTP), the Brier
# reward, and (for 3000 steps) sampled-token RL with K = 64.
# Usage: bash run_bpe.sh
cd "$(dirname "$0")"
PY=${PY:-python3}
[ -f data_bpe/train.bin ] || $PY make_bpe_data.py
mkdir -p ckpt results
$PY pretrain_bpe.py --reward log   --save ckpt/bpe_log.pt   > results/bpe_log.log 2>&1
$PY pretrain_bpe.py --reward brier --save ckpt/bpe_brier.pt > results/bpe_brier.log 2>&1
$PY pretrain_bpe.py --reward pg64  --steps 3000             > results/bpe_pg64.log 2>&1
tail -n 1 results/bpe_log.log results/bpe_brier.log results/bpe_pg64.log
