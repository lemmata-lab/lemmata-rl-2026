#!/bin/bash
# Lean 4 corpus from the local mathlib checkout (no download).
# Usage: bash make_lean_corpus.sh [mathlib_dir]
cd "$(dirname "$0")"
M=${1:-${MATHLIB_SRC:-../lean/.lake/packages/mathlib/Mathlib}}
: > lean_corpus.txt
for d in Logic Order Data/Nat Data/List Data/Finset Algebra/Group Algebra/Order; do
  find "$M/$d" -name '*.lean' | sort | while read -r f; do
    # drop the copyright header and import lines, keep the code and proofs
    sed -e '/^\/-$/,/^-\/$/{/Copyright/,/^-\/$/d}' -e '/^import /d' -e '/^public import /d' -e '/^module$/d' "$f"
    echo
  done >> lean_corpus.txt
  echo "$d $(wc -c < lean_corpus.txt)"
done
