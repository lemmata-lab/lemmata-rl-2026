"""Stage 1 at BPE scale: the agent's action is the whole next-token distribution q,
the environment reveals x and pays a strictly proper score. The expected reward
is computed exactly (no sampling), which is the only practical form at V = 8192:
sampled-token RL needs K on the order of V samples per position.

  --reward log    S(q,x) = log q(x)              (log score; identical to NTP)
  --reward brier  S(q,x) = q(x) - 1/2 ||q||^2    (Brier score up to a constant)
  --reward pgK    sampled-token RL with K samples and the fair group reward (for comparison)

Usage: python pretrain_bpe.py --reward log --steps 15000 --save ckpt/bpe_log.pt
"""
import argparse
import json
import math
import os
import time

import numpy as np
import torch
import torch.nn.functional as F

from gpt import GPT
from rlgpt import objective


def score(reward, logits, x):
    """Per-position reward S(q, x) (to be maximised)."""
    logp = F.log_softmax(logits.float(), -1)
    lx = logp.gather(-1, x[..., None]).squeeze(-1)
    if reward == "log":
        return lx
    q = logp.exp()
    return lx.exp() - 0.5 * (q * q).sum(-1)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--reward", default="log")
    ap.add_argument("--data", default="data_bpe")
    ap.add_argument("--steps", type=int, default=15000)
    ap.add_argument("--B", type=int, default=32)
    ap.add_argument("--T", type=int, default=512)
    ap.add_argument("--d", type=int, default=512)
    ap.add_argument("--L", type=int, default=8)
    ap.add_argument("--h", type=int, default=8)
    ap.add_argument("--lr", type=float, default=6e-4)
    ap.add_argument("--eval_every", type=int, default=500)
    ap.add_argument("--save", default="")
    ap.add_argument("--out", default="results")
    a = ap.parse_args()

    dev = "cuda"
    torch.manual_seed(0)
    tr = np.memmap(os.path.join(a.data, "train.bin"), dtype=np.uint16, mode="r")
    va = np.memmap(os.path.join(a.data, "val.bin"), dtype=np.uint16, mode="r")
    V = 8192

    def batch(d):
        o = np.random.randint(0, len(d) - a.T - 1, a.B)
        w = torch.from_numpy(np.stack([d[i:i + a.T + 1].astype(np.int64) for i in o])).to(dev)
        return w[:, :-1], w[:, 1:]

    model = GPT(V, a.T, a.d, a.L, a.h).to(dev)
    print(f"{sum(p.numel() for p in model.parameters()) / 1e6:.1f}M params")
    opt = torch.optim.AdamW(model.parameters(), lr=a.lr, betas=(0.9, 0.95), weight_decay=0.1, fused=True)
    warm = 500
    sched = torch.optim.lr_scheduler.LambdaLR(opt, lambda s: min(1, (s + 1) / warm) * (
        0.1 + 0.9 * 0.5 * (1 + math.cos(math.pi * min(s, a.steps) / a.steps))))

    @torch.no_grad()
    def evaluate(n=20):
        model.eval()
        ce = br = 0.0
        for _ in range(n):
            inp, tgt = batch(va)
            with torch.autocast("cuda", torch.bfloat16):
                lg = model(inp)
            ce -= score("log", lg, tgt).mean().item()
            br += score("brier", lg, tgt).mean().item()
        model.train()
        return {"val_ce": ce / n, "val_brier": br / n}

    log, t0 = [], time.time()
    for step in range(a.steps + 1):
        if step % a.eval_every == 0:
            m = evaluate() | {"step": step, "min": round((time.time() - t0) / 60, 1)}
            log.append(m)
            print(json.dumps(m), flush=True)
        if step == a.steps:
            break
        inp, tgt = batch(tr)
        with torch.autocast("cuda", torch.bfloat16):
            logits = model(inp)
        if a.reward.startswith("pg"):      # sampled-token RL, fair group reward, K = int(suffix)
            loss = objective("pg", logits.float().reshape(-1, V), tgt.reshape(-1), int(a.reward[2:]))
        else:
            loss = -score(a.reward, logits, tgt).mean()
        opt.zero_grad(set_to_none=True)
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        opt.step()
        sched.step()
        if a.save and step and step % 5000 == 0:
            torch.save({"cfg": model.cfg, "state": model.state_dict()}, a.save)

    os.makedirs(a.out, exist_ok=True)
    json.dump({"args": vars(a), "log": log}, open(os.path.join(a.out, f"bpe_{a.reward}.json"), "w"), indent=1)
    if a.save:
        torch.save({"cfg": model.cfg, "state": model.state_dict()}, a.save)


if __name__ == "__main__":
    main()
