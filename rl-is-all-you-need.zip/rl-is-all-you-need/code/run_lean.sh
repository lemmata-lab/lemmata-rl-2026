#!/bin/bash
# Char-level Lean 4 (mathlib subset). Usage: bash run_lean.sh [steps] [outdir] [methods...]
# Each run saves a checkpoint ckpt/lean_<method>.pt for stage 2 (rl_prove.py).
cd "$(dirname "$0")"
PY=${PY:-python3}
S=${1:-4000}
O=${2:-results}
shift 2 2>/dev/null
METHODS=${*:-"ntp brier pg8 pg32"}
[ -f lean_corpus.txt ] || bash make_lean_corpus.sh
mkdir -p ckpt
COMMON="--data text --text lean_corpus.txt --tag lean --T 128 --d 256 --L 6 --heads 8 --drop 0.1
        --steps $S --eval_every $((S / 10)) --prompt theorem"
for m in $METHODS; do
  case $m in
    pg*) args="--method pg --K ${m#pg}" ;;
    *)   args="--method $m" ;;
  esac
  $PY rlgpt.py $COMMON $args --out $O --save ckpt/lean_$m.pt 2>&1 | grep -v -i warn | grep -v '^$' | tail -14
  echo
done
