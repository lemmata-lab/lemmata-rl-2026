"""Learning-efficiency summary from results/*.json.

For each experiment family, reports the final metric and the number of steps
NTP needed to reach the final value of each RL method ("NTP-equivalent steps"),
by linear interpolation of the NTP curve. Ratio = RL steps / NTP-equivalent steps.
"""
import glob
import json
import os


def curve(path, key):
    log = json.load(open(path))["log"]
    return [(m["step"], m[key]) for m in log if key in m]


def steps_to(c, target):
    """First (interpolated) step where a decreasing curve reaches target."""
    for (s0, v0), (s1, v1) in zip(c, c[1:]):
        if v1 <= target:
            return s0 + (s1 - s0) * (v0 - target) / (v0 - v1) if v0 > target else s0
    return None


def family(prefix, key, ntp_name):
    ntp = curve(f"results/{prefix}_{ntp_name}.json", key)
    rows = []
    for f in sorted(glob.glob(f"results/{prefix}_*.json")):
        name = os.path.basename(f)[len(prefix) + 1:-5]
        c = curve(f, key)
        best = min(v for _, v in c)
        final_step = c[-1][0]
        eq = steps_to(ntp, best)
        rows.append((name, best, final_step, eq, final_step / eq if eq else None))
    print(f"\n== {prefix}  ({key}, lower is better; NTP-equivalent steps from the NTP curve)")
    print(f"{'method':14} {'best':>8} {'RL steps':>9} {'NTP eq.':>8} {'ratio':>6}")
    for n, b, s, e, r in rows:
        print(f"{n:14} {b:8.4f} {s:9d} {e if e is None else round(e):>8} {'' if r is None else f'{r:6.1f}'}")
    return rows


out = {}
out["synth_kl"] = family("synth", "kl", "ntp")
out["synth_sq"] = family("synth", "sq_err", "ntp")
out["lean"] = family("lean", "val_bits", "ntp")
if os.path.exists("results/bpe_log.json") and os.path.exists("results/bpe_brier.json"):
    out["bpe"] = family("bpe", "val_ce", "log")
json.dump(out, open("results/efficiency.json", "w"), indent=1)
