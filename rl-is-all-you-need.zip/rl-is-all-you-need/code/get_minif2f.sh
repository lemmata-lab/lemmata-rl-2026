#!/bin/bash
# Download the Lean 4 miniF2F statements (DeepSeek-Prover-V1.5 release), check which
# elaborate under our Mathlib, and compute the single-tactic and ten-tactic baselines.
# Needs the Lean project in ../lean to be built (see the top-level README).
# Usage: bash get_minif2f.sh
cd "$(dirname "$0")"
PY=${PY:-python3}
mkdir -p data_minif2f
curl -sSL --retry 3 -o data_minif2f/minif2f.jsonl \
  https://raw.githubusercontent.com/deepseek-ai/DeepSeek-Prover-V1.5/main/datasets/minif2f.jsonl
wc -l data_minif2f/minif2f.jsonl
$PY mathlib_verify.py
