#!/bin/bash
# Multi-line proof search with goal states on miniF2F, before and after RL.
cd "$(dirname "$0")"
PY=${PY:-python3}
E=${1:-6}
log() { grep -v -i warn > "$1"; }
# 1) base policy, hybrid search on test   ||   2) RL (expert iteration) on valid
$PY rl_search.py eval  --ckpt ckpt/bpe_log.pt --closers --max_exp $E --out results/search_base_hybrid.json 2>&1 | log results/search_base_hybrid.log &
$PY rl_search.py train --ckpt ckpt/bpe_log.pt --closers --max_exp 4 --rounds 2 --save ckpt/search_rl.pt \
    --out results/search_train.json 2>&1 | log results/search_train.log &
wait
# 3) RL policy, hybrid search on test   ||   4) policy-only search, base vs RL
$PY rl_search.py eval  --ckpt ckpt/search_rl.pt --closers --max_exp $E --out results/search_rl_hybrid.json 2>&1 | log results/search_rl_hybrid.log &
$PY rl_search.py eval  --ckpt ckpt/bpe_log.pt  --max_exp $E --out results/search_base_policy.json 2>&1 | log results/search_base_policy.log &
$PY rl_search.py eval  --ckpt ckpt/search_rl.pt --max_exp $E --out results/search_rl_policy.json 2>&1 | log results/search_rl_policy.log &
wait
for f in results/search_base_hybrid results/search_rl_hybrid results/search_base_policy results/search_rl_policy; do
  echo "$f: $(tail -1 $f.log)"
done
grep '^round' results/search_train.log
