"""Regression test for mathlib_verify: known-good and known-bad candidates in one batch."""
import json

from mathlib_verify import _CACHE, check_many

p = [q for q in json.load(open("data_minif2f/minif2f_checked.json")) if q["ok"]]
solved = json.load(open("data_minif2f/single_tactic_solved.json"))
good = [q for q in p if q["name"] in solved][:3]
stmt = good[0]["formal_statement"]
cases = [
    (stmt, solved[good[0]["name"]][0], True),
    (stmt, "--Countably", False),          # comment only
    (stmt, "skip", False),                 # does nothing
    (good[1]["formal_statement"], solved[good[1]["name"]][0], True),
    (stmt, "exact?", False),               # search tactics are banned (not reproducible proofs)
    (stmt, "norm_num", None),              # filled below: same as baseline result
    (stmt, ".", False),                    # parse error that spills into the next theorem
    (good[2]["formal_statement"], solved[good[2]["name"]][0], True),
    (stmt, "rfl", False),
]
cases = [(s, t, (t in solved[good[0]["name"]]) if w is None else w) for s, t, w in cases]
_CACHE.clear()
res = check_many([(s, t) for s, t, _ in cases], per_file=16)
for (s, t, want), got in zip(cases, res):
    print(f"{'OK ' if got == want else 'BAD'} want={want!s:5} got={got!s:5} {t}")
