"""Batch proof checker: the Lean kernel as an RL reward function.

Each candidate is checked in its own file (core Lean 4, no Mathlib import) so a
malformed candidate cannot break the others. A proof counts as correct only if
Lean reports no error and no `sorry` warning.
"""
import os
import shutil
import subprocess
import tempfile
from concurrent.futures import ThreadPoolExecutor

LEAN = os.environ.get("LEAN") or shutil.which("lean") or os.path.expanduser("~/.elan/bin/lean")
BANNED = ("sorry", "admit", "axiom", "native_decide", "implemented_by", "extern", "unsafe")


def check_one(src, timeout=10):
    if any(b in src for b in BANNED):
        return False
    with tempfile.NamedTemporaryFile("w", suffix=".lean", delete=False) as f:
        f.write(src)
        path = f.name
    try:
        r = subprocess.run([LEAN, path], capture_output=True, text=True, timeout=timeout)
        out = r.stdout + r.stderr
        return r.returncode == 0 and "error" not in out and "sorry" not in out
    except subprocess.TimeoutExpired:
        return False
    finally:
        os.unlink(path)


def check_many(sources, workers=16):
    with ThreadPoolExecutor(workers) as ex:
        return list(ex.map(check_one, sources))


if __name__ == "__main__":
    import time
    stmt = "theorem t (p q : Prop) (hp : p) (hq : q) : p ∧ q := by\n  "
    cands = ["exact ⟨hp, hq⟩", "constructor <;> assumption", "simp [hp, hq]",
             "exact hp", "sorry", "intro h", "omega"] * 4
    t = time.time()
    res = check_many([stmt + c + "\n" for c in cands])
    print(f"{len(cands)} checks in {time.time() - t:.2f}s")
    for c, ok in list(zip(cands, res))[:7]:
        print(f"{ok!s:5}  {c}")
