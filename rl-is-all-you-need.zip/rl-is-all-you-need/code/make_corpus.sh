#!/bin/bash
# Build a local English char-level corpus (no download): license texts shipped with Ubuntu.
cd "$(dirname "$0")"
find -L /usr/share/common-licenses -maxdepth 1 -type f -print0 | sort -z | xargs -0 cat \
  | tr -cd '\11\12\15\40-\176' > corpus.txt
wc -c corpus.txt
