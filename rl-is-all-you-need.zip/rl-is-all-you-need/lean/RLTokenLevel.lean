import RLUniversality

/-! Token-level actions (Section 4 of the paper).

  * `single_sample_not_strict`: with one sampled token per step and ANY reward
    `r : α → α → ℝ`, a source distribution with two distinct support points is
    never the unique maximizer of expected reward (Proposition 2).
  * `two_sample_formula` / `two_sample_gap`: with two independent sampled tokens
    and reward 1{A=x} + 1{A'=x} - 1{A=A'}, expected reward equals
    ‖p‖² - ‖q - p‖², so the regret is exactly the squared error (Proposition 3);
    `two_sample_unique`: the reward is strictly proper on the whole simplex.
  * `regretU_eq_div`: Lemma 1 for an arbitrary single-step expected reward `U`.
  * `token_regret_eq_error` / `token_universal_transfer`: in the two-sample token
    environment, regret = cumulative squared error at every horizon and history,
    and a cumulative-error bound transfers with the same constant (Theorem 4,
    conditional on the Solomonoff bound, as in `universal_transfer`).
  * `biased_two_formula` / `biased_two_gap` / `biased_two_sharpens`: the biased
    (V-statistic) group reward for K = 2 has expectation 2⟨q,p⟩ − ½‖q‖² − ½; the
    unclipped point `2p − c` beats every report by half the squared distance and
    strictly beats `p` unless `p` is uniform (unclipped case of Proposition 5).

  Checked with Lean 4.34.1 / Mathlib v4.34.1 (`lake build`). -/
namespace RLUniversality
open scoped BigOperators

variable {α : Type*} [Fintype α] [DecidableEq α]

/-- Point-mass distribution. -/
noncomputable def pointMass (a : α) : Distribution α where
  prob := fun b => if b = a then 1 else 0
  nonneg := by intro b; split_ifs <;> norm_num
  total := by simp

/-- Expected one-sample reward: action `A ~ q`, token `X ~ p`, independent. -/
noncomputable def singleExpected (r : α → α → ℝ) (p q : Distribution α) : ℝ :=
  ∑ a, q.prob a * ∑ x, p.prob x * r a x

omit [DecidableEq α] in
/-- Expected one-sample reward is an average of per-action values. -/
lemma singleExpected_le_max (r : α → α → ℝ) (p q : Distribution α) (a₀ : α)
    (hmax : ∀ a, (∑ x, p.prob x * r a x) ≤ ∑ x, p.prob x * r a₀ x) :
    singleExpected r p q ≤ ∑ x, p.prob x * r a₀ x := by
  unfold singleExpected
  calc
    (∑ a, q.prob a * ∑ x, p.prob x * r a x)
        ≤ ∑ a, q.prob a * ∑ x, p.prob x * r a₀ x := by
          apply Finset.sum_le_sum
          intro a _
          exact mul_le_mul_of_nonneg_left (hmax a) (q.nonneg a)
    _ = ∑ x, p.prob x * r a₀ x := by
          rw [← Finset.sum_mul, q.total, one_mul]

lemma singleExpected_pointMass (r : α → α → ℝ) (p : Distribution α) (a₀ : α) :
    singleExpected r p (pointMass a₀) = ∑ x, p.prob x * r a₀ x := by
  unfold singleExpected pointMass
  simp [ite_mul]

/-- Single-sample rewards are never strictly proper at a distribution with two
    distinct support points: some other distribution does at least as well. -/
theorem single_sample_not_strict (r : α → α → ℝ) (p : Distribution α)
    (a b : α) (hab : a ≠ b) (ha : 0 < p.prob a) (hb : 0 < p.prob b) :
    ∃ q : Distribution α, q.prob ≠ p.prob ∧
      singleExpected r p p ≤ singleExpected r p q := by
  obtain ⟨a₀, -, hmax⟩ := Finset.exists_max_image Finset.univ
    (fun c => ∑ x, p.prob x * r c x) ⟨a, Finset.mem_univ a⟩
  refine ⟨pointMass a₀, ?_, ?_⟩
  · intro h
    have ha' := congrFun h a
    have hb' := congrFun h b
    simp only [pointMass] at ha' hb'
    split_ifs at ha' with h1 <;> split_ifs at hb' with h2
    all_goals first
      | exact hab (h1.trans h2.symm)
      | linarith
  · rw [singleExpected_pointMass]
    exact singleExpected_le_max r p p a₀ (fun c => hmax c (Finset.mem_univ c))

omit [Fintype α] in
lemma ind_mul (c : ℝ) (a x : α) :
    c * (if a = x then (1 : ℝ) else 0) = if a = x then c else 0 := by
  split_ifs <;> ring

/-- Expected two-sample reward: `A, A' ~ q` i.i.d., `X ~ p`,
    reward 1{A=X} + 1{A'=X} - 1{A=A'}. -/
noncomputable def twoSampleExpected (p q : Distribution α) : ℝ :=
  ∑ a, ∑ b, ∑ x, q.prob a * q.prob b * p.prob x *
    ((if a = x then 1 else 0) + (if b = x then 1 else 0) - (if a = b then 1 else 0))

lemma inner_sum (p q : Distribution α) (a b : α) :
    (∑ x, q.prob a * q.prob b * p.prob x *
      ((if a = x then 1 else 0) + (if b = x then 1 else 0) - (if a = b then 1 else 0)))
      = q.prob a * q.prob b * p.prob a + q.prob a * q.prob b * p.prob b
        - (if a = b then q.prob a * q.prob b else 0) := by
  have hsplit : ∀ x, q.prob a * q.prob b * p.prob x *
      ((if a = x then 1 else 0) + (if b = x then 1 else 0) - (if a = b then 1 else 0))
      = (if a = x then q.prob a * q.prob b * p.prob x else 0)
        + (if b = x then q.prob a * q.prob b * p.prob x else 0)
        - (if a = b then q.prob a * q.prob b else 0) * p.prob x := by
    intro x
    split_ifs <;> ring
  simp_rw [hsplit]
  rw [Finset.sum_sub_distrib, Finset.sum_add_distrib, Finset.sum_ite_eq,
    Finset.sum_ite_eq, ← Finset.mul_sum, p.total]
  simp

lemma twoSample_expand (p q : Distribution α) :
    twoSampleExpected p q =
      2 * (∑ a, q.prob a * p.prob a) - ∑ a, q.prob a ^ 2 := by
  unfold twoSampleExpected
  simp_rw [inner_sum]
  simp only [Finset.sum_add_distrib, Finset.sum_sub_distrib]
  have hA : (∑ a, ∑ b, q.prob a * q.prob b * p.prob a) = ∑ a, q.prob a * p.prob a := by
    apply Finset.sum_congr rfl
    intro a _
    have : (∑ b, q.prob a * q.prob b * p.prob a) =
        q.prob a * p.prob a * ∑ b, q.prob b := by
      rw [Finset.mul_sum]; apply Finset.sum_congr rfl; intro b _; ring
    rw [this, q.total, mul_one]
  have hB : (∑ a, ∑ b, q.prob a * q.prob b * p.prob b) = ∑ b, q.prob b * p.prob b := by
    rw [Finset.sum_comm]
    apply Finset.sum_congr rfl
    intro b _
    have : (∑ a, q.prob a * q.prob b * p.prob b) =
        q.prob b * p.prob b * ∑ a, q.prob a := by
      rw [Finset.mul_sum]; apply Finset.sum_congr rfl; intro a _; ring
    rw [this, q.total, mul_one]
  have hC : (∑ a, ∑ b, (if a = b then q.prob a * q.prob b else 0)) =
      ∑ a, q.prob a ^ 2 := by
    apply Finset.sum_congr rfl
    intro a _
    rw [Finset.sum_ite_eq]
    simp [sq]
  rw [hA, hB, hC]
  ring

/-- Two-sample expected reward = ‖p‖² − ‖q − p‖². -/
theorem two_sample_formula (p q : Distribution α) :
    twoSampleExpected p q = ∑ a, p.prob a ^ 2 - squaredError p q := by
  rw [twoSample_expand]
  unfold squaredError
  have h : (∑ a, p.prob a ^ 2) - ∑ a, (q.prob a - p.prob a) ^ 2 =
      ∑ a, (2 * (q.prob a * p.prob a) - q.prob a ^ 2) := by
    rw [← Finset.sum_sub_distrib]
    apply Finset.sum_congr rfl; intro a _; ring
  rw [h, Finset.sum_sub_distrib, ← Finset.mul_sum]

/-- The two-sample regret is exactly the squared prediction error. -/
theorem two_sample_gap (p q : Distribution α) :
    twoSampleExpected p p - twoSampleExpected p q = squaredError p q := by
  rw [two_sample_formula, two_sample_formula]
  have h0 : squaredError p p = 0 := by unfold squaredError; simp
  rw [h0]; ring

omit [DecidableEq α] in
lemma eq_of_squaredError_zero (p q : Distribution α) (hz : squaredError p q = 0) :
    q.prob = p.prob := by
  funext a
  have hle : (q.prob a - p.prob a) ^ 2 ≤ squaredError p q :=
    Finset.single_le_sum (fun b _ => sq_nonneg (q.prob b - p.prob b)) (Finset.mem_univ a)
  rw [hz] at hle
  nlinarith [sq_nonneg (q.prob a - p.prob a)]

theorem two_sample_optimal (p q : Distribution α) :
    twoSampleExpected p q ≤ twoSampleExpected p p := by
  have := two_sample_gap p q
  have := squaredError_nonneg p q
  linarith

/-- Strict propriety of the two-sample reward on the whole simplex (Proposition 3). -/
theorem two_sample_unique (p q : Distribution α)
    (heq : twoSampleExpected p q = twoSampleExpected p p) : q.prob = p.prob := by
  have hg := two_sample_gap p q
  exact eq_of_squaredError_zero p q (by linarith)

/-! ### Multi-step environments with an arbitrary single-step expected reward

  `U p q` is the expected one-step reward when the next token is drawn from `p`
  and the policy distribution is `q` (for token environments the expectation
  over the sampled actions is already inside `U`). Actions never influence the
  next token, so the history consists of tokens only. -/

section Generic
omit [DecidableEq α]
variable (U : Distribution α → Distribution α → ℝ)

noncomputable def valueU (μ : Source α) (π : Policy α) : ℕ → List α → ℝ
  | 0, _ => 0
  | n + 1, h => U (μ h) (π h) + ∑ x, (μ h).prob x * valueU μ π n (h ++ [x])

/-- Expected cumulative single-step divergence `U p p - U p q`. -/
noncomputable def cumulativeDiv (μ : Source α) (π : Policy α) : ℕ → List α → ℝ
  | 0, _ => 0
  | n + 1, h => (U (μ h) (μ h) - U (μ h) (π h)) +
      ∑ x, (μ h).prob x * cumulativeDiv μ π n (h ++ [x])

/-- Lemma 1 for any single-step reward: regret = expected cumulative divergence. -/
theorem regretU_eq_div (μ : Source α) (π : Policy α) (n : ℕ) (h : List α) :
    valueU U μ μ n h - valueU U μ π n h = cumulativeDiv U μ π n h := by
  induction n generalizing h with
  | zero => simp [valueU, cumulativeDiv]
  | succ n ih =>
    have hs : (∑ x, (μ h).prob x * valueU U μ μ n (h ++ [x])) -
        (∑ x, (μ h).prob x * valueU U μ π n (h ++ [x])) =
        ∑ x, (μ h).prob x * cumulativeDiv U μ π n (h ++ [x]) := by
      rw [← Finset.sum_sub_distrib]
      apply Finset.sum_congr rfl
      intro x _
      rw [← mul_sub, ih]
    simp only [valueU, cumulativeDiv]
    linarith

end Generic

/-- Expected total reward in the two-sample token environment. -/
noncomputable abbrev tokenValue (μ : Source α) (π : Policy α) : ℕ → List α → ℝ :=
  valueU twoSampleExpected μ π

noncomputable def tokenRegret (μ : Source α) (π : Policy α) (n : ℕ) (h : List α) : ℝ :=
  tokenValue μ μ n h - tokenValue μ π n h

/-- Two-sample token environment: regret equals the cumulative squared error
    (no factor 1/2, unlike the Brier environment). -/
theorem token_regret_eq_error (μ : Source α) (π : Policy α) (n : ℕ) (h : List α) :
    tokenRegret μ π n h = cumulativeError μ π n h := by
  unfold tokenRegret tokenValue
  rw [regretU_eq_div]
  induction n generalizing h with
  | zero => simp [cumulativeDiv, cumulativeError]
  | succ n ih =>
    simp only [cumulativeDiv, cumulativeError, two_sample_gap]
    congr 1
    apply Finset.sum_congr rfl
    intro x _
    rw [ih]

theorem token_oracle_optimal (μ : Source α) (π : Policy α) (n : ℕ) (h : List α) :
    tokenValue μ π n h ≤ tokenValue μ μ n h := by
  have he := token_regret_eq_error μ π n h
  have hn := cumulativeError_nonneg μ π n h
  unfold tokenRegret at he
  linarith

/-- Theorem 4 (conditional form): a cumulative-error bound for one policy on a
    source class transfers, with the same constant, to the regret of the policy
    that samples two tokens from it under the fair Brier reward. -/
theorem token_universal_transfer (C : Source α → Prop)
    (hUniversal : ∃ π : Policy α, ∀ μ, C μ →
      ∃ B : ℝ, ∀ n, cumulativeError μ π n [] ≤ B) :
    ∃ π : Policy α, ∀ μ, C μ →
      ∃ B : ℝ, ∀ n, tokenRegret μ π n [] ≤ B := by
  obtain ⟨π, hπ⟩ := hUniversal
  refine ⟨π, fun μ hμ => ?_⟩
  obtain ⟨B, hB⟩ := hπ μ hμ
  exact ⟨B, fun n => by rw [token_regret_eq_error]; exact hB n⟩

/-! ### Biased (V-statistic) group reward, K = 2 (Proposition 5)

  ρᵥ(a, a', x) = 1{a=x} + 1{a'=x} - ¼(1{a=a} + 1{a'=a'} + 2·1{a=a'})
              = 1{a=x} + 1{a'=x} - ½ - ½·1{a=a'}. -/

noncomputable def biasedTwoExpected (p q : Distribution α) : ℝ :=
  ∑ a, ∑ b, ∑ x, q.prob a * q.prob b * p.prob x *
    ((if a = x then 1 else 0) + (if b = x then 1 else 0) - 1 / 2 -
      1 / 2 * (if a = b then 1 else 0))

lemma biased_inner (p q : Distribution α) (a b : α) :
    (∑ x, q.prob a * q.prob b * p.prob x *
      ((if a = x then 1 else 0) + (if b = x then 1 else 0) - 1 / 2 -
        1 / 2 * (if a = b then 1 else 0))) =
    (∑ x, q.prob a * q.prob b * p.prob x *
      ((if a = x then 1 else 0) + (if b = x then 1 else 0) - (if a = b then 1 else 0)))
      + (1 / 2 * (if a = b then q.prob a * q.prob b else 0) - 1 / 2 * (q.prob a * q.prob b)) := by
  have hx : ∀ x, q.prob a * q.prob b * p.prob x *
      ((if a = x then 1 else 0) + (if b = x then 1 else 0) - 1 / 2 -
        1 / 2 * (if a = b then 1 else 0)) =
      q.prob a * q.prob b * p.prob x *
      ((if a = x then 1 else 0) + (if b = x then 1 else 0) - (if a = b then 1 else 0))
      + (1 / 2 * (if a = b then q.prob a * q.prob b else 0)
          - 1 / 2 * (q.prob a * q.prob b)) * p.prob x := by
    intro x
    split_ifs <;> ring
  simp_rw [hx]
  rw [Finset.sum_add_distrib, ← Finset.mul_sum, p.total, mul_one]

/-- Expected biased reward: 2⟨q,p⟩ − ½‖q‖² − ½ (the case K = 2, c = 1/2). -/
theorem biased_two_formula (p q : Distribution α) :
    biasedTwoExpected p q =
      2 * (∑ a, q.prob a * p.prob a) - 1 / 2 * (∑ a, q.prob a ^ 2) - 1 / 2 := by
  have h2 := twoSample_expand p q
  unfold twoSampleExpected at h2
  unfold biasedTwoExpected
  simp_rw [biased_inner]
  simp only [Finset.sum_add_distrib, Finset.sum_sub_distrib]
  rw [h2]
  have hC : (∑ a, ∑ b, 1 / 2 * (if a = b then q.prob a * q.prob b else 0)) =
      1 / 2 * ∑ a, q.prob a ^ 2 := by
    rw [Finset.mul_sum]
    apply Finset.sum_congr rfl
    intro a _
    rw [← Finset.mul_sum, Finset.sum_ite_eq]
    simp [sq]
  have hD : (∑ a, ∑ b, 1 / 2 * (q.prob a * q.prob b)) = 1 / 2 := by
    simp_rw [← Finset.mul_sum, ← Finset.sum_mul, q.total]
    ring
  rw [hC, hD]
  ring

/-- If `q = 2p − c` (the unclipped projection of `p / c'` with c' = 1/2), then
    `q` beats every `q'` by exactly half the squared distance. -/
theorem biased_two_gap (p q q' : Distribution α) (c : ℝ)
    (hq : ∀ a, q.prob a = 2 * p.prob a - c) :
    biasedTwoExpected p q - biasedTwoExpected p q' =
      1 / 2 * ∑ a, (q'.prob a - q.prob a) ^ 2 := by
  rw [biased_two_formula, biased_two_formula]
  have hp : ∀ a, p.prob a = (q.prob a + c) / 2 := fun a => by rw [hq a]; ring
  have key : ∀ a, 2 * (q.prob a * p.prob a) - 1 / 2 * q.prob a ^ 2 -
      (2 * (q'.prob a * p.prob a) - 1 / 2 * q'.prob a ^ 2) =
      1 / 2 * (q'.prob a - q.prob a) ^ 2 + c * (q.prob a - q'.prob a) := by
    intro a
    rw [hp a]
    ring
  calc (2 * (∑ a, q.prob a * p.prob a) - 1 / 2 * (∑ a, q.prob a ^ 2) - 1 / 2) -
        (2 * (∑ a, q'.prob a * p.prob a) - 1 / 2 * (∑ a, q'.prob a ^ 2) - 1 / 2)
      = ∑ a, (2 * (q.prob a * p.prob a) - 1 / 2 * q.prob a ^ 2 -
          (2 * (q'.prob a * p.prob a) - 1 / 2 * q'.prob a ^ 2)) := by
        simp only [Finset.sum_sub_distrib, ← Finset.mul_sum]
        ring
    _ = ∑ a, (1 / 2 * (q'.prob a - q.prob a) ^ 2 + c * (q.prob a - q'.prob a)) :=
        Finset.sum_congr rfl fun a _ => key a
    _ = 1 / 2 * ∑ a, (q'.prob a - q.prob a) ^ 2 := by
        rw [Finset.sum_add_distrib, ← Finset.mul_sum, ← Finset.mul_sum,
          Finset.sum_sub_distrib, q.total, q'.total]
        ring

/-- Biased group rewards sharpen: whenever the unclipped optimum `q = 2p − c` is a
    distribution different from `p` (i.e. `p` is not uniform), it strictly beats
    the truthful report `p`, so the biased reward is not proper. -/
theorem biased_two_sharpens (p q : Distribution α) (c : ℝ)
    (hq : ∀ a, q.prob a = 2 * p.prob a - c) (hne : q.prob ≠ p.prob) :
    biasedTwoExpected p p < biasedTwoExpected p q := by
  have hg := biased_two_gap p q p c hq
  obtain ⟨a, ha⟩ := Function.ne_iff.mp hne
  have hpos : 0 < (p.prob a - q.prob a) ^ 2 := by
    have : p.prob a - q.prob a ≠ 0 := sub_ne_zero.mpr (Ne.symm ha)
    positivity
  have hle : (p.prob a - q.prob a) ^ 2 ≤ ∑ b, (p.prob b - q.prob b) ^ 2 :=
    Finset.single_le_sum (fun b _ => sq_nonneg (p.prob b - q.prob b)) (Finset.mem_univ a)
  linarith

#print axioms single_sample_not_strict
#print axioms two_sample_gap
#print axioms two_sample_unique
#print axioms token_regret_eq_error
#print axioms token_universal_transfer
#print axioms biased_two_sharpens

end RLUniversality
