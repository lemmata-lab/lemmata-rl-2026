import Mathlib.Basic.Real.Basic
import Mathlib.Algebra.Order.BigOperators.Group.Finset
import Mathlib.Tactic

/-! NTP-to-RL reduction. The external universal-prediction theorem is a
    hypothesis of `universal_transfer`, never an axiom introduced here. -/
namespace RLUniversality
open scoped BigOperators

variable {α : Type*} [Fintype α] [DecidableEq α]

structure Distribution (α : Type*) [Fintype α] where
  prob : α → ℝ
  nonneg : ∀ a, 0 ≤ prob a
  total : ∑ a, prob a = 1

noncomputable def reward (q : Distribution α) (x : α) : ℝ :=
  1 - (1 / 2 : ℝ) * ∑ a, (q.prob a - if a = x then 1 else 0) ^ 2

noncomputable def expectedReward (p q : Distribution α) : ℝ :=
  ∑ x, p.prob x * reward q x

noncomputable def squaredError (p q : Distribution α) : ℝ :=
  ∑ a, (q.prob a - p.prob a) ^ 2

lemma coordinate_loss (p q : Distribution α) (a : α) :
    (∑ x, p.prob x * (q.prob a - if a = x then 1 else 0) ^ 2) =
      q.prob a ^ 2 - 2 * p.prob a * q.prob a + p.prob a := by
  have hexp : ∀ x, p.prob x * (q.prob a - if a = x then 1 else 0) ^ 2 =
      p.prob x * q.prob a ^ 2 +
        if a = x then p.prob x * (1 - 2 * q.prob a) else 0 := by
    intro x
    split_ifs <;> ring
  simp_rw [hexp]
  rw [Finset.sum_add_distrib, ← Finset.sum_mul, p.total]
  simp
  ring

lemma expectedReward_formula (p q : Distribution α) :
    expectedReward p q = 1 - (1 / 2 : ℝ) *
      ∑ a, (q.prob a ^ 2 - 2 * p.prob a * q.prob a + p.prob a) := by
  unfold expectedReward reward
  simp_rw [mul_sub, mul_one]
  rw [Finset.sum_sub_distrib, p.total]
  congr 1
  simp_rw [show ∀ x, p.prob x * ((1 / 2 : ℝ) *
      ∑ a, (q.prob a - if a = x then 1 else 0) ^ 2) =
      (1 / 2 : ℝ) * ∑ a, p.prob x *
        (q.prob a - if a = x then 1 else 0) ^ 2 by
    intro x
    rw [← Finset.mul_sum]
    ring]
  rw [← Finset.mul_sum, Finset.sum_comm]
  simp_rw [coordinate_loss]

/-- The conditional expected reward gap is exactly half the squared error. -/
theorem brier_gap (p q : Distribution α) :
    expectedReward p p - expectedReward p q =
      (1 / 2 : ℝ) * squaredError p q := by
  rw [expectedReward_formula, expectedReward_formula]
  unfold squaredError
  rw [show (1 - (1 / 2 : ℝ) * ∑ a,
      (p.prob a ^ 2 - 2 * p.prob a * p.prob a + p.prob a)) -
      (1 - (1 / 2 : ℝ) * ∑ a,
      (q.prob a ^ 2 - 2 * p.prob a * q.prob a + p.prob a)) =
      (1 / 2 : ℝ) * ((∑ a,
      (q.prob a ^ 2 - 2 * p.prob a * q.prob a + p.prob a)) -
      ∑ a, (p.prob a ^ 2 - 2 * p.prob a * p.prob a + p.prob a)) by ring]
  rw [← Finset.sum_sub_distrib]
  congr 1
  apply Finset.sum_congr rfl
  intro a _
  ring

omit [DecidableEq α] in
theorem squaredError_nonneg (p q : Distribution α) :
    0 ≤ squaredError p q :=
  Finset.sum_nonneg fun _ _ => sq_nonneg _

theorem truthful_optimal (p q : Distribution α) :
    expectedReward p q ≤ expectedReward p p := by
  have := brier_gap p q
  have := squaredError_nonneg p q
  linarith

omit [DecidableEq α] in
lemma prob_le_one (q : Distribution α) (a : α) : q.prob a ≤ 1 := by
  calc
    q.prob a ≤ ∑ b, q.prob b :=
      Finset.single_le_sum (fun b _ => q.nonneg b) (Finset.mem_univ a)
    _ = 1 := q.total

/-- The constructed RL reward is bounded in the standard interval [0,1]. -/
theorem reward_bounds (q : Distribution α) (x : α) :
    0 ≤ reward q x ∧ reward q x ≤ 1 := by
  have hsq : (∑ a, q.prob a ^ 2) ≤ 1 := by
    calc
      (∑ a, q.prob a ^ 2) ≤ ∑ a, q.prob a := by
        apply Finset.sum_le_sum
        intro a _
        have h0 := q.nonneg a
        have h1 := prob_le_one q a
        nlinarith
      _ = 1 := q.total
  have hloss : (∑ a, (q.prob a - if a = x then 1 else 0) ^ 2) =
      (∑ a, q.prob a ^ 2) + (1 - 2 * q.prob x) := by
    have hx : ∀ a, (q.prob a - if a = x then 1 else 0) ^ 2 =
        q.prob a ^ 2 + if a = x then 1 - 2 * q.prob a else 0 := by
      intro a
      split_ifs <;> ring
    simp_rw [hx]
    simp only [Finset.sum_add_distrib, Finset.sum_ite_eq', Finset.mem_univ, ite_true]
  have hn : 0 ≤ ∑ a, (q.prob a - if a = x then 1 else 0) ^ 2 :=
    Finset.sum_nonneg fun _ _ => sq_nonneg _
  have h0 := q.nonneg x
  unfold reward
  constructor <;> linarith
/-- Equality of expected reward identifies the whole probability vector. -/
theorem truthful_unique (p q : Distribution α)
    (heq : expectedReward p q = expectedReward p p) : q.prob = p.prob := by
  have hg := brier_gap p q
  have hz : squaredError p q = 0 := by linarith
  funext a
  have hle : (q.prob a - p.prob a) ^ 2 ≤ squaredError p q := by
    exact Finset.single_le_sum (fun b _ => sq_nonneg (q.prob b - p.prob b))
      (Finset.mem_univ a)
  rw [hz] at hle
  nlinarith [sq_nonneg (q.prob a - p.prob a)]
/-- Both source and policy map the observed token history to a distribution.
    The source does NOT depend on the reported action. -/
abbrev Source (α : Type*) [Fintype α] := List α → Distribution α
abbrev Policy (α : Type*) [Fintype α] := List α → Distribution α

/-- Exact finite-horizon expected cumulative error, integrating each next token
    against the source distribution. This includes expectation over histories. -/
noncomputable def cumulativeError (μ : Source α) (π : Policy α) :
    ℕ → List α → ℝ
  | 0, _ => 0
  | n + 1, h => squaredError (μ h) (π h) +
      ∑ x, (μ h).prob x * cumulativeError μ π n (h ++ [x])

/-- Expected total reward in the action-independent prediction environment. -/
noncomputable def value (μ : Source α) (π : Policy α) : ℕ → List α → ℝ
  | 0, _ => 0
  | n + 1, h => expectedReward (μ h) (π h) +
      ∑ x, (μ h).prob x * value μ π n (h ++ [x])

noncomputable def regret (μ : Source α) (π : Policy α) (n : ℕ)
    (h : List α) : ℝ := value μ μ n h - value μ π n h

/-- Finite-horizon reduction, valid at every history. -/
theorem regret_eq_half_error (μ : Source α) (π : Policy α) (n : ℕ)
    (h : List α) : regret μ π n h = (1 / 2 : ℝ) * cumulativeError μ π n h := by
  induction n generalizing h with
  | zero => simp [regret, value, cumulativeError]
  | succ n ih =>
    have hs : (∑ x, (μ h).prob x * value μ μ n (h ++ [x])) -
        (∑ x, (μ h).prob x * value μ π n (h ++ [x])) =
        (1 / 2 : ℝ) * ∑ x, (μ h).prob x * cumulativeError μ π n (h ++ [x]) := by
      rw [← Finset.sum_sub_distrib, Finset.mul_sum]
      apply Finset.sum_congr rfl
      intro x _
      rw [← mul_sub]
      have hx := ih (h ++ [x])
      unfold regret at hx
      rw [hx]
      ring
    unfold regret
    simp only [value, cumulativeError]
    have hg := brier_gap (μ h) (π h)
    linarith

omit [DecidableEq α] in
theorem cumulativeError_nonneg (μ : Source α) (π : Policy α)
    (n : ℕ) (h : List α) : 0 ≤ cumulativeError μ π n h := by
  induction n generalizing h with
  | zero => simp [cumulativeError]
  | succ n ih =>
    exact add_nonneg (squaredError_nonneg _ _)
      (Finset.sum_nonneg fun x _ => mul_nonneg ((μ h).nonneg x) (ih _))

/-- The known-source predictor is optimal for every finite horizon. -/
theorem oracle_optimal (μ : Source α) (π : Policy α) (n : ℕ) (h : List α) :
    value μ π n h ≤ value μ μ n h := by
  have he := regret_eq_half_error μ π n h
  have hn := cumulativeError_nonneg μ π n h
  unfold regret at he
  linarith

/-- A theorem schema for ANY source class C. To specialize to computable
    sources, supply the Solomonoff bound as hUniversal. No computability
    of the witness policy is claimed. -/
theorem universal_transfer (C : Source α → Prop)
    (hUniversal : ∃ π : Policy α, ∀ μ, C μ →
      ∃ B : ℝ, ∀ n, cumulativeError μ π n [] ≤ B) :
    ∃ π : Policy α, ∀ μ, C μ →
      ∃ B : ℝ, ∀ n, regret μ π n [] ≤ B := by
  obtain ⟨π, hπ⟩ := hUniversal
  refine ⟨π, ?_⟩
  intro μ hμ
  obtain ⟨B, hB⟩ := hπ μ hμ
  refine ⟨B / 2, ?_⟩
  intro n
  rw [regret_eq_half_error]
  have := hB n
  linarith

/-- Irreversible two-environment counterexample: at least one environment
    has average reward gap at least 1/2, whatever the initial mixing p. -/
theorem irreversible_gap (p : ℝ) :
    (1 / 2 : ℝ) ≤ 1 - p ∨ (1 / 2 : ℝ) ≤ p := by
  by_cases h : (1 / 2 : ℝ) ≤ p
  · exact Or.inr h
  · left; linarith

#print axioms brier_gap
#print axioms regret_eq_half_error
#print axioms universal_transfer
end RLUniversality




