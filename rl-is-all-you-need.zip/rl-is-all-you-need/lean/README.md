# Lean 4 formalization

Lean 4.34.1 with Mathlib v4.34.1 (pinned in `lean-toolchain`, `lakefile.toml`, `lake-manifest.json`).

```bash
lake exe cache get
lake build
```

`lake build` checks both files and prints `#print axioms` for the key theorems; the expected output is in `verification.txt`. Every theorem depends only on `propext`, `Classical.choice` and `Quot.sound`; there is no `sorry`.

## `RLUniversality.lean`: the reduction (paper Section 3)

| Theorem | Content |
|---|---|
| `brier_gap` | single-step expected reward gap = ½ × squared prediction error |
| `reward_bounds` | the Brier reward lies in [0, 1] |
| `truthful_optimal`, `truthful_unique` | the true distribution is the unique maximizer of expected reward |
| `regret_eq_half_error` | cumulative expected regret = ½ × cumulative expected error, every horizon and history |
| `oracle_optimal` | the informed policy is optimal at every horizon |
| `universal_transfer` | a horizon-free error bound for one policy on a source class gives a regret bound for the same policy |
| `irreversible_gap` | numerical core of the two-environment trap example |

## `RLTokenLevel.lean`: sampled tokens (paper Section 4)

| Theorem | Content |
|---|---|
| `single_sample_not_strict` | single-sample rewards are never strictly proper |
| `two_sample_gap`, `two_sample_unique` | the two-sample fair Brier reward: regret = squared error, strictly proper |
| `regretU_eq_div` | regret = cumulative divergence for any single-step expected reward |
| `token_regret_eq_error`, `token_universal_transfer` | universality transfer in the two-sample token environment |
| `biased_two_sharpens` | the biased group reward (K = 2) strictly prefers a sharpened distribution |

## Not formalized

The Solomonoff bound enters `universal_transfer` and `token_universal_transfer` as an explicit hypothesis, not as an axiom. The universal semimeasure, measures on infinite sequences, general interactive environments and the optimality of any training algorithm are not formalized.
