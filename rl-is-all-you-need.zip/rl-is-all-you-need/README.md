# Reinforcement Learning Is All You Need

Code, Lean proofs, results and LaTeX source for the paper

> **Reinforcement Learning Is All You Need: Next-Token Prediction as a Special Case of Reward Maximization, and a Research Program for RL-Native Language Models.** Lemmata, 2026.
> PDF: [`paper/Reinforcement Learning Is All You Need.pdf`](paper/Reinforcement%20Learning%20Is%20All%20You%20Need.pdf)

With the next-token distribution as action and a strictly proper scoring rule as reward, next-token prediction (NTP) is a special case of reinforcement learning (RL): regret equals prediction error, and with the logarithmic score the policy gradient *is* the cross-entropy gradient. This repository contains the machine-checked core of that argument (Lean 4), small Transformers trained from scalar rewards alone, and RL from the Lean proof checker on miniF2F.

## Layout

```
lean/     Lean 4 + Mathlib formalization (Section 5); also the Mathlib environment used by the verifiers
code/     training, verification and analysis scripts (flat layout; run everything from code/)
code/results/            every number in the paper, as JSON curves and logs
code/data_minif2f/       our baseline results on miniF2F (the statements themselves are downloaded)
paper/    LaTeX source, bibliography and the compiled PDF
```

## Setup

**Python** (3.10+; a CUDA GPU is strongly recommended):

```bash
pip install -r requirements.txt
```

**Lean.** Install [elan](https://github.com/leanprover/elan), then build the Lean project. This fetches Mathlib v4.34.1 and its prebuilt cache, checks the proofs, and makes `lean/` usable as the Mathlib environment for the proof-checking experiments:

```bash
cd lean
lake exe cache get
lake build
```

The core-Lean experiment (`rl_prove.py`) only needs a `lean` binary on `PATH`.

**Environment variables** (all optional): `PY` (Python interpreter for the shell scripts, default `python3`), `MATHLIB_PROJECT` (Lake project with Mathlib built, default `../lean`), `MATHLIB_SRC` (Mathlib source tree for the corpora, default `../lean/.lake/packages/mathlib/Mathlib`), `LEAN`, `LAKE`.

## Paper ↔ code

Run every command from `code/`. Times are for one laptop RTX PRO 4000 Blackwell (16 GB) with 20 CPU cores.

| Paper | What | Command | Results |
|---|---|---|---|
| §5, Lean table | machine-checked theorems | `cd ../lean && lake build` | `lean/verification.txt` |
| §6, Table 1 | synthetic source with known truth (7 training signals) | `bash run_synth.sh` (~7 min) | `results/synth_*.json` |
| §6 (text) | English character-level text | `bash make_corpus.sh && bash run_text.sh 1500 results/text1500` | `results/text1500/` |
| §6, Fig. 1 left | Lean, character level | `bash run_lean.sh` (~20 min) | `results/lean_*.json` |
| §6, Fig. 1 right | Lean, BPE (29.7M params) | `bash run_bpe.sh` (~2 h) | `results/bpe_*.json`, `bpe_*.log` |
| §6, Table 2 | per-step time and memory | `python bench.py` | `results/bench.txt` |
| §6, Table 3 | steps to equal quality | `python analyze.py` | `results/efficiency.json` |
| §7, toy propositions | verifier RL, with/without anchor | `bash run_prove.sh` (needs `ckpt/lean_pg32.pt` from `run_lean.sh`) | `results/prove_anchor*.json` |
| §7, miniF2F setup | statements and the ten-tactic baseline | `bash get_minif2f.sh` (~20 min) | `data_minif2f/*_solved.json` |
| §7, Table 4 (one line) | anti-collapse ablations, 2 seeds | `bash run_collapse.sh && bash run_skeleton.sh` | `results/collapse_*.json` |
| §7, Table 4, Fig. 2 (multi-line) | goal-state search and expert iteration | `bash run_search.sh`; tactic-only baseline: `python rl_search.py eval --closers --k 0` | `results/search_*.json` |
| §7, pitfalls | verifier regression test; tactic prior | `python test_verify.py`; `python tactic_prior.py` | — |

Two result sets document the pitfalls reported in §7 and are kept for transparency: `results/old_prompt/` (one-line runs with the prompt that ended in a bare newline token) and `results/prove2_log_a0.5.*` (the first miniF2F run, before the verifier fix and the prompt fix). They are superseded by `collapse_*` and are not used in the paper's tables.

## Main files

| File | Role |
|---|---|
| `rlgpt.py` | small GPT and the five training signals (`ntp`, `brier`, `pg`, `pgv`, `pg1`) at character level |
| `gpt.py`, `pretrain_bpe.py` | BPE-scale model; rewards `log` (= NTP), `brier`, `pgK` |
| `lean_verify.py` | core-Lean checker (one file per candidate) |
| `mathlib_verify.py` | batched Mathlib checker with error attribution, caching and candidate filtering |
| `lean_state.py` | runs a proof prefix and returns proved / open goals / error |
| `rl_prove.py`, `rl_prove2.py` | verifier RL for one-line proofs (core Lean; Mathlib/miniF2F), with anchor, diversity and novelty rewards |
| `rl_search.py` | best-first multi-line search with goal states, expert iteration, closer-only baseline |
| `analyze.py`, `bench.py`, `tactic_prior.py`, `test_verify.py` | analysis and checks |

## Data sources

- **Mathlib** (Apache-2.0) is fetched by Lake; the corpora are built locally from it by `make_lean_corpus.sh` and `make_bpe_data.py` and are not redistributed.
- **miniF2F** Lean 4 statements are downloaded by `get_minif2f.sh` from the DeepSeek-Prover-V1.5 repository and are not redistributed here.
- **English text** (`make_corpus.sh`) is built from the license texts in `/usr/share/common-licenses` of a Debian/Ubuntu system.

Checkpoints are not included (the BPE checkpoints are ~120 MB each); every result can be regenerated with the commands above.

## Citation

```bibtex
@misc{lemmata2026rlallyouneed,
  title  = {Reinforcement Learning Is All You Need: Next-Token Prediction as a Special Case
            of Reward Maximization, and a Research Program for {RL}-Native Language Models},
  author = {Lemmata},
  year   = {2026}
}
```

## License

MIT; see [`LICENSE`](LICENSE). The license covers everything in this repository: the code, the Lean sources, the results, and the paper (LaTeX source and PDF). Third-party data fetched by the scripts (Mathlib, miniF2F statements) remains under its own license.
